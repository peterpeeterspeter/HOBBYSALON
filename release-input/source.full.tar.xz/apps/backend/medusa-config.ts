import { defineConfig, loadEnv, Modules } from '@medusajs/framework/utils'
import type { InputConfig, InputConfigModules } from '@medusajs/types'
import { resolveSigningSecrets } from './src/utils/signing-secrets'

loadEnv(process.env.NODE_ENV || 'development', process.cwd())

// Fail closed before constructing config/providers; validate the loaded environment.
const signingSecrets = resolveSigningSecrets(process.env)
const redisUrl = process.env.REDIS_URL?.trim() || undefined
if (process.env.NODE_ENV === 'production' && !redisUrl) {
  throw new Error('REDIS_URL must be configured in production for the Redis event bus and workflow engine.')
}

const shouldEnableAlgolia =
  process.env.CI !== 'true' &&
  process.env.ENABLE_ALGOLIA === 'true' &&
  process.env.DISABLE_ALGOLIA !== 'true' &&
  Boolean(process.env.ALGOLIA_APP_ID) &&
  Boolean(process.env.ALGOLIA_API_KEY)

const publicBackendUrl = (
  process.env.BACKEND_URL ||
  process.env.MEDUSA_BACKEND_URL ||
  "http://localhost:9000"
).replace(/\/$/, "")

const fileModule = process.env.S3_ACCESS_KEY_ID
  ? {
      resolve: "@medusajs/medusa/file",
      options: {
        providers: [
          {
            resolve: "@medusajs/medusa/file-s3",
            id: "s3",
            options: {
              file_url: process.env.S3_FILE_URL,
              access_key_id: process.env.S3_ACCESS_KEY_ID,
              secret_access_key: process.env.S3_SECRET_ACCESS_KEY,
              region: process.env.S3_REGION,
              bucket: process.env.S3_BUCKET,
              endpoint: process.env.S3_ENDPOINT,
            },
          },
        ],
      },
    }
  : {
      resolve: "@medusajs/medusa/file",
      options: {
        providers: [
          {
            resolve: "@medusajs/medusa/file-local",
            id: "local",
            options: {
              upload_dir: "static",
              // Without this, Medusa stores http://localhost:9000/static/...
              // which breaks production image URLs after deploy.
              backend_url: `${publicBackendUrl}/static`,
            },
          },
        ],
      },
    }

const modules: InputConfigModules = [
    // projectConfig.redisUrl alone does not replace Medusa's in-memory defaults.
    // These option shapes are read by the installed Medusa 2.11.3 loaders.
    // Local development/test without Redis deliberately retain those defaults.
    ...(redisUrl
      ? [
          {
            key: Modules.EVENT_BUS,
            resolve: '@medusajs/event-bus-redis',
            options: { redisUrl }
          },
          {
            key: Modules.WORKFLOW_ENGINE,
            resolve: '@medusajs/workflow-engine-redis',
            options: { redis: { url: redisUrl } }
          }
        ]
      : []),
    // Messaging/workflow Redis is not a replacement for the commerce PG lock.
    fileModule,
    {
      key: Modules.PAYMENT,
      resolve: './src/modules/payment-capture-recovery',
      options: {
        providers: [
          {
            resolve:
              '@mercurjs/payment-stripe-connect/providers/stripe-connect',
            id: 'stripe-connect',
            options: {
              apiKey: process.env.STRIPE_SECRET_API_KEY,
              webhookSecret:
                process.env.STRIPE_PAYMENT_WEBHOOK_SECRET ??
                process.env.STRIPE_WEBHOOK_SECRET
            }
          }
        ]
      }
    },
    {
      key: Modules.ORDER,
      resolve: './src/modules/order-commerce-serialization'
    },
    {
      key: Modules.NOTIFICATION,
      resolve: './src/modules/notification-retry-identity',
      options: {
        providers: [
          {
            resolve: '@mercurjs/resend/providers/resend',
            id: 'resend',
            options: {
              channels: ['email'],
              api_key: process.env.RESEND_API_KEY,
              from: process.env.RESEND_FROM_EMAIL
            }
          },
          {
            resolve: '@medusajs/medusa/notification-local',
            id: 'local',
            options: {
              channels: ['feed', 'seller_feed']
            }
          }
        ]
      }
    },
    {
      resolve: './src/modules/index-runtime-readonly'
    }
  ]

module.exports = defineConfig({
  admin: {
    disable: true // Disable built-in admin - using separate admin-panel container
  },
  projectConfig: {
    databaseUrl: process.env.DATABASE_URL,
    redisUrl,
    workerMode:
      (process.env.WORKER_MODE as "shared" | "server" | "worker" | undefined) ??
      "shared",
    databaseDriverOptions:
      process.env.NODE_ENV === 'production' &&
      process.env.DATABASE_SSL !== 'false'
        ? {
            connection: {
              ssl: { rejectUnauthorized: false }
            }
          }
        : undefined,
    http: {
      storeCors: process.env.STORE_CORS!,
      adminCors: process.env.ADMIN_CORS!,
      vendorCors: process.env.VENDOR_CORS!,
      authCors: process.env.AUTH_CORS!,
      jwtSecret: signingSecrets.jwtSecret,
      cookieSecret: signingSecrets.cookieSecret
    }
  },
  plugins: [
    {
      resolve: '@mercurjs/b2c-core',
      options: {}
    },
    {
      resolve: '@mercurjs/commission',
      options: {}
    },
    ...(shouldEnableAlgolia
      ? [
          {
            resolve: '@mercurjs/algolia',
            options: {
              apiKey: process.env.ALGOLIA_API_KEY,
              appId: process.env.ALGOLIA_APP_ID
            }
          }
        ]
      : []),
    {
      resolve: '@mercurjs/reviews',
      options: {}
    },
    {
      resolve: '@mercurjs/requests',
      options: {}
    },
    {
      resolve: '@mercurjs/resend',
      options: {}
    }
  ],
  modules,
} as InputConfig)
