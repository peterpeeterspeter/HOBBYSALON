import { createHash } from 'node:crypto'
import { PaymentActions } from '@medusajs/framework/utils'
import { assertCommerceFinancialLock, withCommerceCartLock, commerceCartLockQuery } from '@mercurjs/b2c-core/utils/commerce-cart-lock'
import { assertMarketplaceCompletionHooksSupported } from '@mercurjs/b2c-core/workflows/cart/workflows/split-and-complete-cart'
import { isCommercePaymentsEnabled } from '../api/middlewares/commerce-payment-policy'
import { marketplacePaymentContext } from './marketplace-payment-webhook'
import { completeMarketplaceWebhookDb, marketplaceWebhookCartShape } from './marketplace-webhook-completion'
import { applyMarketplaceWebhookTransaction, marketplaceWebhookFingerprint, readCommittedMarketplaceWebhookReceipt } from './marketplace-webhook-transaction'
const fail = (): never => { throw new Error('Atomic webhook replay requires verified immutable reservation and completed capture; reconciliation required') }
const stable = (v: any): string => JSON.stringify(v,(_k,x) => x && typeof x==='object' && !Array.isArray(x)
  ? Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])) : x)
/** No synthetic Stripe identity, no reservation creation, no authorize/capture/refund.
 * Only admitted events with an existing immutable reservation can be replayed.
 * Provider adapter is constrained to status READ; incomplete/uncertain stays pending. */
export async function replayMarketplaceWebhookAdmission(container: any, eventId: string): Promise<any> {
  if (!isCommercePaymentsEnabled() || typeof eventId !== 'string' || !eventId) fail()
  const payment = container.resolve('payment'), manager = payment?.baseRepository_?.manager_
  if (!manager?.fork || !manager?.execute || manager.getTransactionContext()) fail()
  const root = manager.fork({clear:true,useContext:false,disableContextResolution:true})
  const hints = await root.execute('SELECT input,fingerprint,cart_id,session_id FROM marketplace_webhook_admission WHERE event_id=?',[eventId])
  if (!Array.isArray(hints) || hints.length !== 1) fail()
  const cartId = hints[0].cart_id
  return withCommerceCartLock(container,cartId,async () => {
    const admissions = (await commerceCartLockQuery(container,cartId,
      'SELECT input,fingerprint,cart_id,session_id FROM marketplace_webhook_admission WHERE event_id=?',[eventId])).rows
    if (admissions?.length !== 1 || admissions[0].cart_id !== cartId) fail()
    // Independent mutable cursor; never write accepted identity or immutable tail.
    // The lock session runs autocommitted SQL with synchronous_commit=on, BEFORE
    // graph/provider status reads and outside the later business transaction.
    await commerceCartLockQuery(container,cartId,`INSERT INTO marketplace_webhook_replay_attempt (event_id)
      VALUES (?) ON CONFLICT (event_id) DO NOTHING`,[eventId])
    const claims = (await commerceCartLockQuery(container,cartId,`UPDATE marketplace_webhook_replay_attempt x
      SET last_attempt_at=now(), attempts=x.attempts+1, last_error=NULL
      FROM marketplace_webhook_admission a JOIN marketplace_capture_tail t ON t.cart_id=a.cart_id
      WHERE x.event_id=? AND a.event_id=x.event_id AND a.cart_id=?
      AND t.snapshot->>'protocol'='atomic-stripe-event'
      AND NOT EXISTS (SELECT 1 FROM marketplace_stripe_event_receipt r WHERE r.event_id=a.event_id)
      AND (x.last_attempt_at IS NULL OR x.last_attempt_at<now()-interval '5 minutes')
      RETURNING x.attempts,x.last_attempt_at`,[eventId,cartId])).rows
    if (!Array.isArray(claims) || claims.length > 1) fail()
    try {
      const input = JSON.parse(JSON.stringify(admissions[0].input)), fingerprint = marketplaceWebhookFingerprint(input)
      if (input.event_id !== eventId || input.data.cart_id !== cartId || input.data.session_id !== admissions[0].session_id ||
          admissions[0].fingerprint !== fingerprint || hints[0].fingerprint !== fingerprint ||
          input.provider_id !== 'pp_card_stripe-connect' || ![PaymentActions.AUTHORIZED,PaymentActions.SUCCESSFUL].includes(input.action)) fail()
      if (await readCommittedMarketplaceWebhookReceipt(root,input)) return {duplicate:true}
      if (!claims.length) return {deferred:true}
      assertCommerceFinancialLock()
      assertMarketplaceCompletionHooksSupported()
      const {session,cart} = await marketplacePaymentContext(container,input)
      if (!cart || cart.id !== input.data.cart_id || session.payment_collection_id !== input.data.payment_collection_id) fail()
      const tails = (await commerceCartLockQuery(container,cart.id,'SELECT * FROM marketplace_capture_tail WHERE cart_id=?',[cart.id])).rows
      if (tails?.length !== 1) fail()
      const tail = tails[0], s = tail.snapshot
      if (!s || s.version !== 1 || s.protocol !== 'atomic-stripe-event' || tail.payment_id !== s.payment_id ||
          tail.cart_id !== cart.id || s.cart_id !== cart.id || !tail.capture_id || !s.cart_snapshot ||
          !Array.isArray(s.allocations) || s.allocations.length ||
          tail.event_id !== `marketplace-captured-${createHash('sha256').update(stable(s)).digest('hex')}` ||
          s.session_id !== input.data.session_id || s.collection_id !== input.data.payment_collection_id ||
          s.intent_id !== input.data.payment_intent_id || s.provider_id !== input.provider_id ||
          s.amount !== input.data.amount || s.currency_code !== input.data.currency_code) fail()
      const shape = (c: any) => {const {completed_at:_completed,...v}=marketplaceWebhookCartShape(c);return v}
      if (stable(shape(cart)) !== stable(shape(s.cart_snapshot))) fail()
      if (typeof payment.prepareMarketplaceWebhookCapture_ !== 'function') fail()
      const expected = {session_id:s.session_id,collection_id:s.collection_id,intent_id:s.intent_id,amount:s.amount,currency_code:s.currency_code}
      const prepared = await payment.prepareMarketplaceWebhookCapture_({cart_id:cart.id,cart,expected,action:input.action,
        recovery_only:true,reservation:Object.freeze({payment_id:tail.payment_id,capture_id:tail.capture_id})})
      assertCommerceFinancialLock(); assertMarketplaceCompletionHooksSupported()
      if (prepared.payment_id !== tail.payment_id || prepared.capture_id !== tail.capture_id) fail()
      return await applyMarketplaceWebhookTransaction(root,input,async scope => {
        const current = await scope.execute('SELECT * FROM marketplace_capture_tail WHERE payment_id=? FOR UPDATE',[tail.payment_id])
        if (current.length !== 1 || current[0].event_id !== tail.event_id || current[0].capture_id !== tail.capture_id ||
            stable(current[0].snapshot) !== stable(s)) fail()
        return completeMarketplaceWebhookDb(scope,container,{cart,expected_payment:expected,prepared_capture:prepared,event_id:eventId})
      })
    } catch (error) {
      if (claims.length) await commerceCartLockQuery(container,cartId,
        'UPDATE marketplace_webhook_replay_attempt SET last_error=? WHERE event_id=?',
        ['Atomic replay reconciliation required; no automatic financial retry',eventId])
      throw error
    }
  })
}
