import { createHash } from 'node:crypto'

/** Private candidate kernel wired through authenticated admission, provider
 * preparation and DB-only completion. A workflow ID is never accepted as a
 * transaction. Native MikroORM forks share one Knex trx.
 */
export interface MarketplaceWebhookIdentity {
  event_id: string
  action: string
  provider_id: string
  data: { cart_id: string; session_id: string; payment_collection_id: string;
    payment_intent_id: string; amount: string; currency_code: string }
}
function identity(input: MarketplaceWebhookIdentity): string {
  const values = [input.event_id, input.provider_id, input.action, input.data?.cart_id,
    input.data?.session_id, input.data?.payment_collection_id, input.data?.payment_intent_id,
    input.data?.amount, input.data?.currency_code]
  if (values.some(v => typeof v !== 'string' || !v || v.trim() !== v || /[\u0000-\u001f\u007f]/.test(v))) {
    throw new Error('Invalid durable webhook identity')
  }
  return createHash('sha256').update(JSON.stringify(values)).digest('hex')
}
export const marketplaceWebhookFingerprint = identity
function database(manager: any): string {
  if (!manager?.config?.get) throw new Error('Native ORM configuration unavailable')
  // Normalize native effective connection settings, not default clientUrl text.
  // Never expose configuration/credentials in errors or logs.
  const options = manager.getConnection?.().getConnectionOptions?.()
  return JSON.stringify(options ? [options.host, options.port, options.database, manager.config.get('schema') ?? 'public']
    : ['host', 'port', 'dbName', 'schema'].map(k => manager.config.get(k) ?? null))
}
/** Read only committed receipts under the cart lock, BEFORE provider preparation.
 * INSERT uniqueness inside apply remains authoritative for concurrent writers. */
export async function readCommittedMarketplaceWebhookReceipt(manager: any, input: MarketplaceWebhookIdentity): Promise<boolean> {
  const fingerprint = identity(input)
  if (manager.getTransactionContext()) throw new Error('Receipt lookup requires a root manager')
  const rows = await manager.execute('SELECT fingerprint FROM marketplace_stripe_event_receipt WHERE event_id = ?', [input.event_id])
  if (!Array.isArray(rows) || rows.length > 1) throw new Error('Invalid committed receipt result')
  if (!rows.length) return false
  if (rows[0].fingerprint !== fingerprint) throw new Error('Stripe event identity collision')
  return true
}
export class MarketplaceWebhookDbScope {
  private active = true
  private readonly transaction: any
  constructor(private readonly owner: any) {
    this.transaction = owner.getTransactionContext()
    if (!this.transaction?.isTransaction || this.transaction.isCompleted()) throw new Error(`Physical Knex transaction required (present=${!!this.transaction}, native=${this.transaction?.isTransaction}, completed=${this.transaction?.isCompleted?.()})`)
  }
  assertActive(): void {
    if (!this.active || this.transaction.isCompleted() || this.owner.getTransactionContext() !== this.transaction) {
      throw new Error('Webhook DB transaction authority expired')
    }
  }
  close(): void { this.active = false }
  /** Call-local native fork only: no shared service/prototype/global mutation. */
  context(manager: any): { transactionManager: any } {
    this.assertActive()
    if (database(manager) !== database(this.owner)) throw new Error('Webhook module database mismatch')
    const fork = manager.fork({ clear: true, useContext: false })
    fork.setTransactionContext(this.transaction)
    if (fork.getTransactionContext() !== this.transaction) throw new Error('Webhook module transaction mismatch')
    return { transactionManager: fork }
  }
  async execute(sql: string, bindings: any[] = []): Promise<any[]> {
    this.assertActive()
    const rows = await this.owner.execute(sql, bindings)
    this.assertActive()
    if (!Array.isArray(rows)) throw new Error('Unexpected native SQL result')
    return rows
  }
}
/** All callback writes MUST use scope contexts, including links and inventory.
 * Provider calls, reservation creation, workflow orchestration and Redis emits
 * are prohibited here. Receipt insertion is part of apply, not inbox admission.
 */
export async function applyMarketplaceWebhookTransaction<T>(manager: any, input: MarketplaceWebhookIdentity,
  apply: (scope: MarketplaceWebhookDbScope) => Promise<T>): Promise<{ duplicate: boolean; result?: T }> {
  const fingerprint = identity(input)
  if (manager.getTransactionContext()) throw new Error('Webhook apply requires a root transaction boundary')
  return manager.transactional(async (owner: any) => {
    const scope = new MarketplaceWebhookDbScope(owner)
    try {
      await scope.execute('SET LOCAL synchronous_commit = on')
      const inserted = await scope.execute(`INSERT INTO marketplace_stripe_event_receipt
        (event_id, fingerprint, cart_id, payment_collection_id, payment_intent_id, action)
        VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT (event_id) DO NOTHING RETURNING event_id`,
        [input.event_id, fingerprint, input.data.cart_id, input.data.payment_collection_id, input.data.payment_intent_id, input.action])
      if (!inserted.length) {
        const existing = await scope.execute('SELECT fingerprint FROM marketplace_stripe_event_receipt WHERE event_id = ?', [input.event_id])
        if (existing.length !== 1 || existing[0].fingerprint !== fingerprint) throw new Error('Stripe event identity collision')
        return { duplicate: true }
      }
      const result = await apply(scope)
      scope.assertActive()
      return { duplicate: false, result }
    } finally { scope.close() }
  }, { clear: true })
}
