import { MathBN, PaymentSessionStatus } from '@medusajs/framework/utils'
import type { MarketplaceWebhookDbScope } from './marketplace-webhook-transaction'

/** Internal DB-only adapter, not a public payment entry or replacement capture.
 * The caller must validate provider receipt/minor units, persisted capture ID,
 * immutable cart snapshot, ownership and quarantine BEFORE invoking this code.
 * No provider dispatch or native capturePayment call occurs in this transaction.
 * Candidate only: production integration is intentionally not enabled.
 */
export interface PreparedMarketplaceCapture {
  session_id: string
  provider_id: string
  intent_id: string
  amount: string
  currency_code: string
  payment_id: string
  collection_id: string
  capture_id: string
  cart_id: string
  captured_at: Date
  receipt: Record<string, unknown>
  allocations: { order_id: string; split_id: string; amount: string; currency_code: string }[]
}
export async function finalizePreparedMarketplaceCapture(scope: MarketplaceWebhookDbScope,
  services: { payment: any; paymentManager: any; order: any; orderManager: any; split: any; splitManager: any; contextExtras?: Record<string, unknown> },
  prepared: PreparedMarketplaceCapture): Promise<void> {
  if (!prepared.allocations?.length || !(prepared.captured_at instanceof Date) || !Number.isFinite(prepared.captured_at.getTime())) throw new Error('Prepared capture allocations or timestamp unavailable')
  if (new Set(prepared.allocations.map(a => a.order_id)).size !== prepared.allocations.length ||
    new Set(prepared.allocations.map(a => a.split_id)).size !== prepared.allocations.length ||
    prepared.allocations.some(a => !a.order_id || !a.split_id || !a.currency_code || !MathBN.gte(a.amount,0))) throw new Error('Invalid prepared capture allocations')
  const pc = Object.assign(scope.context(services.paymentManager), services.contextExtras)
  const oc = Object.assign(scope.context(services.orderManager), services.contextExtras)
  const sc = Object.assign(scope.context(services.splitManager), services.contextExtras)
  // Never synthesize capture identity. A committed reservation must exist before
  // provider dispatch; rollbacks here must retain it for the next locked retry.
  const captures = await scope.execute(`SELECT c.id FROM capture c JOIN payment p ON p.id=c.payment_id
    WHERE c.id=? AND p.id=? AND p.payment_collection_id=? AND c.deleted_at IS NULL
    AND p.deleted_at IS NULL FOR UPDATE OF c,p`, [prepared.capture_id, prepared.payment_id, prepared.collection_id])
  if (captures.length !== 1 || captures[0].id !== prepared.capture_id) throw new Error('Committed capture reservation unavailable')
  scope.assertActive()
  const sessions = await scope.execute(`SELECT s.id,s.payment_collection_id,s.provider_id,s.currency_code,s.amount,s.data,s.authorized_at
    FROM payment_session s JOIN payment p ON p.payment_session_id=s.id
    WHERE s.id=? AND p.id=? AND s.deleted_at IS NULL AND p.deleted_at IS NULL FOR UPDATE OF s,p`,
    [prepared.session_id,prepared.payment_id])
  const session = sessions[0]
  if (sessions.length !== 1 || session.id !== prepared.session_id || session.payment_collection_id !== prepared.collection_id ||
    session.provider_id !== prepared.provider_id || session.currency_code !== prepared.currency_code ||
    !MathBN.eq(session.amount,prepared.amount) || session.data?.id !== prepared.intent_id || prepared.receipt.id !== prepared.intent_id ||
    prepared.receipt.status !== 'succeeded') throw new Error('Prepared session binding changed')
  scope.assertActive()
  await services.payment.paymentSessionService_.update({ id: prepared.session_id, data: prepared.receipt,
    status: PaymentSessionStatus.CAPTURED, authorized_at: session.authorized_at ?? prepared.captured_at }, pc)
  scope.assertActive()
  await services.payment.paymentService_.update({ id: prepared.payment_id, data: prepared.receipt, captured_at: prepared.captured_at }, pc)
  scope.assertActive()
  await services.payment.maybeUpdatePaymentCollection_(prepared.collection_id, pc)
  for (const allocation of prepared.allocations) {
    scope.assertActive()
    const existing = await services.order.listOrderTransactions({ order_id: allocation.order_id,
      reference: 'capture', reference_id: prepared.capture_id }, { take: 2, withDeleted: true }, oc)
    if (existing.length) {
      if (existing.length !== 1 || existing[0].deleted_at || existing[0].currency_code !== allocation.currency_code ||
        !MathBN.eq(existing[0].amount,allocation.amount)) throw new Error('Prepared capture accounting mismatch')
    } else {
      await services.order.addOrderTransactions({ order_id: allocation.order_id, amount: allocation.amount,
        currency_code: allocation.currency_code, reference: 'capture', reference_id: prepared.capture_id }, oc)
    }
    scope.assertActive()
    await services.split.updateSplitOrderPayments({ id: allocation.split_id, status: 'captured', captured_amount: allocation.amount }, sc)
  }
  scope.assertActive()
  const tails = await scope.execute(`UPDATE marketplace_capture_tail SET capture_id=COALESCE(capture_id, ?),
    accounting_at=COALESCE(accounting_at, now()), updated_at=now()
    WHERE payment_id=? AND cart_id=? AND (capture_id IS NULL OR capture_id=?) RETURNING payment_id`,
    [prepared.capture_id, prepared.payment_id, prepared.cart_id, prepared.capture_id])
  if (tails.length !== 1) throw new Error('Prepared capture tail binding mismatch')
}
