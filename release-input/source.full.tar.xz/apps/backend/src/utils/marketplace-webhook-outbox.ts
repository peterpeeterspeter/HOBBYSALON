import { ContainerRegistrationKeys, Modules } from '@medusajs/framework/utils'

/** Private candidate TRANSPORT ONLY. enqueued_at records broker acceptance;
 * delivered_at is reserved for a future verified consumer ACK. Never finances.
 * Retained BullMQ jobs do not retry when re-added after exhausted failure.
 * The registered job is disabled until atomic consumers are independently accepted.
 */
export async function dispatchMarketplaceWebhookOutbox(pg: any, eventBus: any): Promise<{
  attempted: number; enqueued: number; failed: number
}> {
  if (!pg?.raw || pg.isTransaction || typeof eventBus?.emit !== 'function') {
    throw new Error('Webhook outbox requires root storage and native event bus')
  }
  const result = { attempted: 0, enqueued: 0, failed: 0 }
  for (let n = 0; n < 20; n++) {
    // One autocommitted statement: no open SQL transaction across broker await.
    // The receipt join admits only already committed webhook business apply.
    const claimed = await pg.raw(`WITH candidate AS (
      SELECT o.id FROM marketplace_webhook_outbox o
      JOIN marketplace_stripe_event_receipt r ON r.event_id=o.event_id
      WHERE o.enqueued_at IS NULL AND o.delivered_at IS NULL AND o.available_at<=now()
      ORDER BY o.available_at,o.created_at,o.id LIMIT 1 FOR UPDATE OF o SKIP LOCKED
    ) UPDATE marketplace_webhook_outbox o
      SET attempts=o.attempts+1,available_at=now()+interval '5 minutes',last_error=NULL
      FROM candidate c WHERE o.id=c.id
      RETURNING o.id,o.event_id,o.event_name,o.payload,o.attempts`)
    if (!Array.isArray(claimed?.rows) || claimed.rows.length > 1) throw new Error('Invalid webhook outbox claim')
    if (!claimed.rows.length) break
    const row = claimed.rows[0]
    if (typeof row.id !== 'string' || !/^[a-f0-9]{64}$/.test(row.id) ||
        !Number.isSafeInteger(row.attempts) || row.attempts < 1) throw new Error('Invalid webhook outbox claim identity')
    result.attempted++
    try {
      const message = row.payload
      const plain = (x: any) => x && typeof x === 'object' && !Array.isArray(x)
      if (typeof row.event_id !== 'string' || !row.event_id || typeof row.event_name !== 'string' || !row.event_name ||
          !plain(message) || message.name !== row.event_name || !plain(message.data) ||
          (message.metadata !== undefined && !plain(message.metadata)) ||
          (message.options !== undefined && !plain(message.options)) ||
          message.metadata?.eventGroupId != null || message.metadata?.completedSubscriberIds != null) {
        throw new Error('Unsupported webhook outbox message')
      }
      // Stored event.options override emit's second argument in Medusa2.11.3.
      // Copy data/metadata; ignore persisted scheduling/repeat/parent options.
      // This transport owns all scheduling authority, not the stored event.
      await eventBus.emit({ ...message, metadata: { ...message.metadata,
        marketplace_webhook_outbox_id: row.id, marketplace_webhook_event_id: row.event_id },
        options: { jobId: `marketplace-webhook-${row.id}`,
          removeOnComplete: false, removeOnFail: false, attempts: 10, delay: 0,
          backoff: { type: 'exponential', delay: 1000 } } })
    } catch {
      const failed = await pg.raw(`UPDATE marketplace_webhook_outbox
        SET last_error=?,available_at=now()+interval '5 minutes'
        WHERE id=? AND attempts=? AND enqueued_at IS NULL AND delivered_at IS NULL RETURNING id`,
        ['Webhook outbox transport failed; reconciliation may be required',row.id,row.attempts])
      if (!Array.isArray(failed?.rows) || failed.rows.length !== 1 || failed.rows[0].id !== row.id) throw new Error('Webhook outbox claim changed')
      result.failed++
      continue
    }
    // Storage failure/unknown outcome propagates; never reinterpret as emit failure.
    // A later replay retains the same broker ID, but real Redis durability is open.
    const saved = await pg.raw(`UPDATE marketplace_webhook_outbox SET enqueued_at=now(),last_error=NULL
      WHERE id=? AND attempts=? AND enqueued_at IS NULL AND delivered_at IS NULL RETURNING id`, [row.id,row.attempts])
    if (!Array.isArray(saved?.rows) || saved.rows.length !== 1 || saved.rows[0].id !== row.id) throw new Error('Webhook outbox claim changed')
    result.enqueued++
  }
  return result
}

export async function runMarketplaceWebhookOutboxTransport(container: any): Promise<void> {
  // Exact opt-in is intentionally stricter than the commerce creation policy.
  // No production flag/config is changed by this private source implementation.
  if (process.env.COMMERCE_WEBHOOK_OUTBOX_TRANSPORT_ENABLED !== 'true') return
  await dispatchMarketplaceWebhookOutbox(container.resolve(ContainerRegistrationKeys.PG_CONNECTION),container.resolve(Modules.EVENT_BUS))
}
