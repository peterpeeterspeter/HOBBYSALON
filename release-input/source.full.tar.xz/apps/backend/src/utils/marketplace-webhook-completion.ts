import { createHash } from 'node:crypto'
import { ContainerRegistrationKeys, MathBN, MessageAggregator, OrderStatus, OrderWorkflowEvents } from '@medusajs/framework/utils'
import { assertCommerceCartLock, assertCommerceFinancialLock, assertCommercePaymentLock } from '@mercurjs/b2c-core/utils/commerce-cart-lock'
import { commerceNativeFence } from '@mercurjs/b2c-core/utils/commerce-native-fence'
import { assertExpectedCartPayment, ExpectedCartPayment } from '@mercurjs/b2c-core/utils/expected-cart-payment'
import { assertCompletedCartOrderSet } from '@mercurjs/b2c-core/utils/completed-cart-order-set'
import { prepareLineItemData, prepareTaxLinesData, prepareAdjustmentsData } from '@mercurjs/b2c-core/workflows/cart/utils/prepare-line-item-data'
import { prepareConfirmInventoryInput } from '@mercurjs/b2c-core/workflows/cart/utils/prepare-confirm-inventory-input'
import type { MarketplaceWebhookDbScope } from './marketplace-webhook-transaction'
import { finalizePreparedMarketplaceCapture, PreparedMarketplaceCapture } from './marketplace-webhook-finalization'

/** Native decorators see an empty flushable aggregator, while messages remain
 * available for the transaction outbox. No singleton/event-bus override. */
export class WebhookOutboxMessages extends MessageAggregator {
  override count(): number { return 0 }
  drain(): any[] { return Object.values(super.getMessages()).flat() }
}
export interface MarketplaceCompletionInput {
  cart: any // completeCartFields snapshot, read/validated during provider preparation
  expected_payment: ExpectedCartPayment
  prepared_capture: Omit<PreparedMarketplaceCapture, 'allocations'> & { allocations?: readonly PreparedMarketplaceCapture['allocations'][number][] }
  event_id: string
  /** Explicit fail-closed guard for installations registering arbitrary workflow hooks. */
  unsupported_hooks?: boolean
}
export interface MarketplaceCompletionResult {
  id: string
  branch: 'new_cart' | 'completed_cart'
  order_ids: string[]
  allocations: { order_id: string; split_id: string; amount: string; currency_code: string }[]
  outbox_ids: string[]
}
const relations = ['items', 'items.tax_lines', 'items.adjustments', 'shipping_methods',
  'shipping_methods.tax_lines', 'shipping_methods.adjustments', 'shipping_address', 'billing_address']
function fail(message: string): never { throw new Error(`Marketplace webhook completion: ${message}`) }
function stable(value: any): string {
  return JSON.stringify(value, (_key, v) => v && typeof v === 'object' && !Array.isArray(v) && !(v instanceof Date)
    ? Object.fromEntries(Object.keys(v).sort().map(k => [k, v[k]])) : v)
}
function scalar(v: any): any { return v?.toNumber ? v.toNumber() : v }
function cartShape(c: any): any {
  const fields = (v: any, names: string[]): Record<string, any> => Object.fromEntries(names.map(k => [k, scalar(v?.[k]) ?? null]))
  const adjustment = (a: any) => fields(a, ['id','amount','code','promotion_id','description'])
  const tax = (a: any) => fields(a, ['id','rate','code','tax_rate_id','provider_id'])
  const rows = (values: any[], keys: string[]) => (values ?? []).map(v => {
    const projected = fields(v, keys), id: unknown = projected['id']
    if (typeof id !== 'string') return fail('invalid cart row identifier')
    return { ...projected, id,
      adjustments: (v.adjustments ?? []).map(adjustment).sort((a: any,b: any) => stable(a).localeCompare(stable(b))),
      tax_lines: (v.tax_lines ?? []).map(tax).sort((a: any,b: any) => stable(a).localeCompare(stable(b)))
    }
  }).sort((a,b) => a.id.localeCompare(b.id))
  return { ...fields(c,['id','currency_code','email','customer_id','sales_channel_id','region_id','completed_at','total']),
    items: rows(c.items,['id','variant_id','product_id','quantity','unit_price','compare_at_unit_price','is_tax_inclusive','requires_shipping','metadata']),
    shipping_methods: rows(c.shipping_methods,['id','shipping_option_id','name','description','amount','is_tax_inclusive','data','metadata']),
    shipping_address: fields(c.shipping_address,['id','first_name','last_name','address_1','address_2','city','country_code','postal_code','province','phone','company']),
    billing_address: fields(c.billing_address,['id','first_name','last_name','address_1','address_2','city','country_code','postal_code','province','phone','company']) }
}
export const marketplaceWebhookCartShape = cartShape
/** Call-local module facade: preserve native module receiver semantics, but fence
 * every internal service/repository too. Native internal services retain their
 * REAL receiver (private event subscriber WeakMaps). */
export function scopedWebhookService(service: any, check: () => void): any {
  const local = Object.create(service)
  // Generated MedusaService methods access __container__, not named fields.
  if (service.__container__) {
    const localContainer = Object.create(service.__container__)
    for (const key of Object.keys(service.__container__)) {
      const value = service.__container__[key]
      if (/Service$|Repository$/.test(key) && value && typeof value === 'object') {
        Object.defineProperty(localContainer,key,{value:commerceNativeFence(value,check),configurable:true})
      }
    }
    Object.defineProperty(local,'__container__',{value:localContainer,configurable:true})
  }
  for (const key of Object.keys(service)) {
    if (/Service_$|Repository_$/.test(key) && service[key] && typeof service[key] === 'object') {
      Object.defineProperty(local,key,{ value: commerceNativeFence(service[key],check), configurable: true })
    }
  }
  return commerceNativeFence(local,check)
}
function managerOf(service: any): any {
  const manager = service?.baseRepository_?.manager_ ?? service?.manager_
  if (!manager) fail('native module manager unavailable')
  return manager
}

/** Native Link forwards one context to modules with DIFFERENT entity metadata.
 * Replace managers at each module's actual argument position, never on a singleton. */
export function scopedWebhookLink(rawLink: any, scope: MarketplaceWebhookDbScope, check: () => void): any {
  check()
  if (!(rawLink?.modulesMap instanceof Map)) {
    // Explicit plain service doubles have no native routing. A native instance
    // without its map must never silently use the caller's cart manager.
    if (rawLink && Object.getPrototypeOf(rawLink) === Object.prototype &&
        !('modulesMap' in rawLink) && !rawLink.__type && !rawLink.__definition &&
        !rawLink.__joinerConfig && !rawLink.MedusaContextIndex_) return commerceNativeFence(rawLink,check)
    fail('native link modules map unavailable')
  }
  const localLink = Object.create(rawLink)
  const contextIndex: Record<string,number> = {
    retrieve: 2, list: 2, listAndCount: 2, create: 3, dismiss: 2,
    delete: 1, softDelete: 2, restore: 2,
  }
  const modulesMap = new Map([...rawLink.modulesMap].map(([key,value]: any) => {
    const rootManager = managerOf(value)
    // Native fork otherwise resolves an ambient ORM named "default" before it
    // reads metadata; pin this module's own receiver before scope.context forks.
    const manager = rootManager.fork({clear:true,useContext:false,disableContextResolution:true})
    scope.context(manager) // validate database before any link read/write
    const fenced = scopedWebhookService(value,check), localModule = Object.create(value)
    for (const [name,index] of Object.entries(contextIndex)) {
      if (typeof value[name] !== 'function') continue
      Object.defineProperty(localModule,name,{configurable:true,value:async (...input: any[]) => {
        check()
        const args = [...input], own = scope.context(manager)
        args[index] = { ...(args[index] ?? {}), ...own, manager: own.transactionManager }
        check()
        try { return await fenced[name](...args) } finally { check() }
      }})
    }
    return [key,localModule]
  }))
  Object.defineProperty(localLink,'modulesMap',{value:modulesMap,configurable:true})
  return commerceNativeFence(localLink,check)
}

/** Invoke ONLY inside applyMarketplaceWebhookTransaction, under the existing
 * commerce cart capability. All native contexts share its physical Knex trx.
 * Never invokes workflows, payment authorization/capture/refund, providers or Redis. */
export async function completeMarketplaceWebhookDb(scope: MarketplaceWebhookDbScope,
  container: any, input: MarketplaceCompletionInput): Promise<MarketplaceCompletionResult> {
  const cartId = input.cart?.id
  const check = () => { scope.assertActive(); assertCommerceCartLock(container,cartId); assertCommerceFinancialLock() }
  check()
  if (input.unsupported_hooks) fail('external workflow hooks require a DB-only adapter')
  const prepared = {...input.prepared_capture,receipt:JSON.parse(JSON.stringify(input.prepared_capture.receipt)),captured_at:new Date(input.prepared_capture.captured_at)}, expected = {...input.expected_payment}
  if (!expected || prepared.cart_id !== cartId || prepared.collection_id !== expected.collection_id || !input.event_id) fail('prepared identity mismatch')
  // Snapshot input is copied before awaits; caller mutation cannot change admission.
  const snapshot = JSON.parse(JSON.stringify(input.cart))
  snapshot.region_id ??= snapshot.region?.id
  snapshot.customer_id ??= snapshot.customer?.id
  await assertCommercePaymentLock(prepared.payment_id,prepared.collection_id); check()
  const messages = new WebhookOutboxMessages()
  const get = (key: string) => {
    const raw = container.resolve(key)
    return { service: scopedWebhookService(raw,check), context: { ...scope.context(managerOf(raw)), messageAggregator: messages }, manager: managerOf(raw) }
  }
  const cartModule = get('cart'), payment = get('payment'), order = get('order'), split = get('split_order_payment')
  const marketplace = get('marketplace'), seller = get('seller'), inventory = get('inventory'), promotion = get('promotion')
  const rawLink = container.resolve(ContainerRegistrationKeys.LINK)
  // Context extras travel unchanged; each native link module injects its own EM.
  const linkContext = { ...cartModule.context, messageAggregator: messages }
  const link = scopedWebhookLink(rawLink,scope,check)
  const locked = await scope.execute('SELECT id FROM cart WHERE id=? AND deleted_at IS NULL FOR UPDATE',[cartId]); check()
  if (locked.length !== 1) fail('cart unavailable')
  await scope.execute('SELECT id FROM cart_line_item WHERE cart_id=? AND deleted_at IS NULL ORDER BY id FOR UPDATE',[cartId])
  await scope.execute('SELECT id FROM cart_shipping_method WHERE cart_id=? AND deleted_at IS NULL ORDER BY id FOR UPDATE',[cartId])
  const cart = await cartModule.service.retrieveCart(cartId,{ relations },cartModule.context); check()
  if (stable(cartShape(cart)) !== stable(cartShape(snapshot))) fail('locked cart snapshot changed')
  const collection = await payment.service.retrievePaymentCollection(expected.collection_id,{ relations: ['payment_sessions'] },payment.context)
  const collectionLinks = await link.list({ cart: { cart_id: cartId }, payment: { payment_collection_id: expected.collection_id } },{},linkContext)
  if (collectionLinks.length !== 1) fail('cart payment collection link mismatch')
  cart.payment_collection = collection
  const sessions = collection.payment_sessions?.filter((s: any) => s.status === 'pending' || s.status === 'authorized' || s.status === 'captured') ?? []
  if (!sessions.length) fail('cart has no pending or authorized payment session')
  assertExpectedCartPayment(cart,sessions,expected,cartId)
  const currentPayment = await payment.service.retrievePayment(prepared.payment_id,{ relations: ['captures','refunds'] },payment.context)
  if (currentPayment.payment_collection_id !== expected.collection_id || currentPayment.payment_session_id !== expected.session_id ||
    currentPayment.currency_code !== expected.currency_code || !MathBN.eq(currentPayment.amount,expected.amount) || currentPayment.canceled_at || currentPayment.refunds?.length) fail('native payment changed')
  if (currentPayment.captures?.length !== 1 || currentPayment.captures[0].id !== prepared.capture_id || !MathBN.eq(currentPayment.captures[0].amount,expected.amount)) fail('prepared full capture reservation mismatch')
  const sets = await marketplace.service.listOrderSets({cart_id: cartId},{take: 2},marketplace.context)
  let set: any, orders: any[], allocations: MarketplaceCompletionResult['allocations'], branch: MarketplaceCompletionResult['branch']
  if (sets.length) {
    branch = 'completed_cart'; set = sets[0]
    const orderLinks = await link.list({marketplace:{order_set_id:set.id},order:{}},{},linkContext)
    if (!orderLinks.length) fail('completed order set has no orders')
    await scope.execute('SELECT id FROM "order" WHERE id=ANY(?::text[]) AND deleted_at IS NULL ORDER BY id FOR UPDATE',[orderLinks.map((l: any) => l.order_id)])
    orders = await order.service.listOrders({id: orderLinks.map((l: any) => l.order_id)},{relations:['items','summary']},order.context)
    for (const o of orders) {
      const links = await link.list({order:{order_id:o.id},payment:{}},{},linkContext)
      o.payment_collections = links.map((l: any) => ({id:l.payment_collection_id}))
      const splitLinks = await link.list({order:{order_id:o.id},split_order_payment:{}},{},linkContext)
      if (splitLinks.length !== 1) fail('completed split order link missing')
      const splits = await split.service.listSplitOrderPayments({id:splitLinks[0].split_order_payment_id},{take:2},split.context)
      if (splits.length !== 1) fail('completed order split mismatch')
      o.split_order_payment = splits[0]
    }
    set.orders = orders
    assertCompletedCartOrderSet(cart,sets,cartId,expected)
    allocations = orders.map(o => ({order_id:o.id,split_id:o.split_order_payment.id,amount:MathBN.convert(o.summary.accounting_total).toString(),currency_code:o.currency_code}))
  } else {
    branch = 'new_cart'
    if (cart.completed_at || !cart.items?.length) fail('cart incomplete or empty')
    const productIds = [...new Set(cart.items.map((i: any) => i.product_id))]
    const products = await link.list({seller:{},product:{product_id:productIds}},{},linkContext)
    const sellerIds = [...new Set(products.map((p: any) => p.seller_id))]
    const sellers = await seller.service.listSellers({id:sellerIds},{},seller.context)
    if (sellers.length !== sellerIds.length || sellers.some((s: any) => s.store_status !== 'ACTIVE')) fail('inactive or missing seller')
    const optionIds = cart.shipping_methods.map((m: any) => m.shipping_option_id)
    if (new Set(optionIds).size !== optionIds.length) fail('duplicate shipping methods')
    const shipping = await link.list({seller:{},fulfillment:{shipping_option_id:optionIds}},{},linkContext)
    if (shipping.some((s: any) => !sellerIds.includes(s.seller_id))) fail('shipping option not available for cart seller')
    const groups = new Map<string,any[]>(), variants = new Map<string,any>()
    for (const item of cart.items) {
      const owners = products.filter((p: any) => p.product_id === item.product_id)
      if (owners.length !== 1) fail('product seller binding missing or ambiguous')
      const variant = snapshot.items.find((i: any) => i.id === item.id)?.variant
      if (!variant || variant.id !== item.variant_id || variant.product?.id !== item.product_id || !MathBN.gt(item.quantity,0)) fail('invalid cart variant or quantity')
      // Pure preparation utility requires calculated_price only when no explicit
      // compare price exists; full graph does not project that derived property.
      const v = {...variant,product_id:item.product_id,inventory_items:(variant.inventory_items ?? []).map((ii: any) => ({...ii,variant_id:variant.id})),calculated_price:variant.calculated_price ?? {calculated_price:{price_list_type:'override'},original_amount:item.unit_price,calculated_amount:item.unit_price}}
      variants.set(v.id,v)
      const owner = owners[0].seller_id
      groups.set(owner,[...(groups.get(owner) ?? []),{...item,variant:v}])
    }
    const orderedSellers = [...groups.keys()]
    const ordersToCreate = orderedSellers.map(id => {
      const methods = cart.shipping_methods.filter((m: any) => shipping.some((s: any) => s.seller_id === id && s.shipping_option_id === m.shipping_option_id))
      if (methods.length !== 1) fail('seller shipping method missing or ambiguous')
      const sm = methods[0]
      const items = groups.get(id)!.map(item => prepareLineItemData({item,variant:item.variant,unitPrice:item.unit_price,compareAtUnitPrice:item.compare_at_unit_price,isTaxInclusive:item.is_tax_inclusive,quantity:item.quantity,metadata:item.metadata,taxLines:item.tax_lines ?? [],adjustments:item.adjustments ?? []}))
      return {region_id:cart.region_id,customer_id:cart.customer_id,sales_channel_id:cart.sales_channel_id,status:OrderStatus.PENDING,email:cart.email,currency_code:cart.currency_code,shipping_address:cart.shipping_address,billing_address:cart.billing_address,no_notification:false,items,promo_codes:items.flatMap(i => i.adjustments ?? []).map(a => a.code).filter(Boolean),shipping_methods:[{name:sm.name,description:sm.description,amount:sm.amount,is_tax_inclusive:sm.is_tax_inclusive,shipping_option_id:sm.shipping_option_id,data:sm.data,metadata:sm.metadata,tax_lines:prepareTaxLinesData(sm.tax_lines ?? []),adjustments:prepareAdjustmentsData(sm.adjustments ?? [])}]}
    })
    const usage = [...cart.items,...cart.shipping_methods].flatMap((i: any) => i.adjustments ?? []).map((a: any) => ({amount:a.amount,code:a.code}))
    // Lock affected promotion rows before native usage validation/update.
    if (usage.length) await scope.execute('SELECT id FROM promotion WHERE code=ANY(?::text[]) AND deleted_at IS NULL ORDER BY id FOR UPDATE',[usage.map((u: any) => u.code)])
    if (usage.length) await promotion.service.registerUsage(usage,{customer_id:cart.customer_id ?? null,customer_email:cart.email ?? null},promotion.context)
    set = await marketplace.service.createOrderSets({cart_id:cartId,customer_id:cart.customer_id,sales_channel_id:cart.sales_channel_id,payment_collection_id:prepared.collection_id},marketplace.context)
    // Native createOrders reloads by ID; bulk list ordering is not seller ordering.
    orders = []
    for (const toCreate of ordersToCreate) orders.push(await order.service.createOrders(toCreate,order.context))
    if (!Array.isArray(orders) || orders.length !== orderedSellers.length) fail('native order creation cardinality mismatch')
    if (!MathBN.eq(orders.reduce((sum,o) => MathBN.add(sum,o.summary?.accounting_total ?? 0),MathBN.convert(0)),expected.amount)) fail('native order accounting total mismatch')
    // Split model has NO order_id column; identity is the native order/split link.
    // Single create per order prevents relying on database bulk result ordering.
    allocations = []
    for (const o of orders) {
      const created = await split.service.createSplitOrderPayments([{status:'pending',currency_code:o.currency_code,authorized_amount:o.summary.accounting_total,payment_collection_id:prepared.collection_id}],split.context)
      if (created.length !== 1) fail('native split cardinality mismatch')
      allocations.push({order_id:o.id,split_id:created[0].id,amount:MathBN.convert(o.summary.accounting_total).toString(),currency_code:o.currency_code})
    }
    const links = orders.flatMap((o,index) => [
      {seller:{seller_id:orderedSellers[index]},order:{order_id:o.id}},
      {marketplace:{order_set_id:set.id},order:{order_id:o.id}},
      {order:{order_id:o.id},payment:{payment_collection_id:prepared.collection_id}},
      {order:{order_id:o.id},split_order_payment:{split_order_payment_id:allocations[index].split_id}}
    ])
    await link.create(links,linkContext)
    const formatted = prepareConfirmInventoryInput({input:{sales_channel_id:cart.sales_channel_id,variants:[...variants.values()],items:orders.flatMap(o => o.items.map((i: any) => ({id:i.id,variant_id:i.variant_id,quantity:i.quantity})))}})
    const reservations: any[] = []
    for (const item of formatted.items) {
      if (!item.location_ids.length) fail('inventory has no stock location')
      const quantity = MathBN.mult(item.quantity,item.required_quantity)
      // Lock before native availability/validation/write to prevent overselling.
      await scope.execute('SELECT id FROM inventory_level WHERE inventory_item_id=? AND location_id=ANY(?::text[]) AND deleted_at IS NULL ORDER BY id FOR UPDATE',[item.inventory_item_id,item.location_ids])
      const levels = await inventory.service.listInventoryLevels({inventory_item_id:item.inventory_item_id,location_id:item.location_ids},{},inventory.context)
      const location = levels.find((l: any) => MathBN.gte(MathBN.sub(l.stocked_quantity,l.reserved_quantity),quantity)) ?? (item.allow_backorder ? levels[0] : undefined)
      if (!location) fail('insufficient inventory')
      reservations.push({line_item_id:item.id,inventory_item_id:item.inventory_item_id,location_id:location.location_id,quantity,allow_backorder:item.allow_backorder})
    }
    if (reservations.length) await inventory.service.createReservationItems(reservations,inventory.context)
    await cartModule.service.updateCarts({id:cartId,completed_at:prepared.captured_at},cartModule.context)
    messages.save({name:OrderWorkflowEvents.PLACED,data:{order_ids:orders.map(o => o.id)}})
    messages.save({name:'order_set.placed',data:{id:set.id}})
  }
  await finalizePreparedMarketplaceCapture(scope,{payment:payment.service,paymentManager:payment.manager,order:order.service,orderManager:order.manager,split:split.service,splitManager:split.manager,contextExtras:{messageAggregator:messages}}, {...prepared,allocations})
  const outboxIds: string[] = []
  for (const [index,message] of messages.drain().entries()) {
    check()
    const payload = JSON.stringify(message), id = createHash('sha256').update(`${input.event_id}:${index}:${payload}`).digest('hex')
    const rows = await scope.execute(`INSERT INTO marketplace_webhook_outbox (id,event_id,event_name,payload)
      VALUES (?,?,?,?::jsonb) ON CONFLICT (id) DO NOTHING RETURNING id`,[id,input.event_id,message.name ?? message.eventName,payload])
    if (rows.length !== 1) fail('outbox event collision')
    outboxIds.push(id)
  }
  check()
  // Append actual DB allocations, not a rewrite of the immutable pre-dispatch reservation.
  // This manifest and outbox have the same receipt/business transaction boundary.
  const manifest = {event_id:input.event_id,payment_id:prepared.payment_id,capture_id:prepared.capture_id,
    cart_id:cartId,order_set_id:set.id,allocations,outbox_ids:outboxIds}
  const commits = await scope.execute(`INSERT INTO marketplace_webhook_commit
    (event_id,payment_id,capture_id,cart_id,order_set_id,allocations,outbox_ids)
    VALUES (?,?,?,?,?,?::jsonb,?::jsonb) RETURNING event_id`,
    [manifest.event_id,manifest.payment_id,manifest.capture_id,manifest.cart_id,manifest.order_set_id,stable(allocations),stable(outboxIds)])
  check()
  if (commits.length !== 1 || commits[0].event_id !== input.event_id) fail('commit manifest unavailable')
  return { id:set.id,branch,order_ids:orders.map(o => o.id),allocations,outbox_ids:outboxIds }
}
