import { ContainerRegistrationKeys, MathBN, PaymentActions, MedusaError } from "@medusajs/framework/utils"
import { assertCommerceFinancialLock, withCommerceCartLock } from "@mercurjs/b2c-core/utils/commerce-cart-lock"
import { assertCompletedCartOrderSet, completedOrderSetFields } from "@mercurjs/b2c-core/utils/completed-cart-order-set"
import { completeCartFields } from "@mercurjs/b2c-core/workflows/cart/utils/complete-cart-fields"
import { assertMarketplaceCompletionHooksSupported } from "@mercurjs/b2c-core/workflows/cart/workflows/split-and-complete-cart"
import { assertExpectedCartPayment } from "@mercurjs/b2c-core/utils/expected-cart-payment"
import { isCommercePaymentsEnabled } from "../api/middlewares/commerce-payment-policy"
import { applyMarketplaceWebhookTransaction, readCommittedMarketplaceWebhookReceipt } from "./marketplace-webhook-transaction"
import { completeMarketplaceWebhookDb } from "./marketplace-webhook-completion"
import { persistMarketplaceWebhookAdmission } from './marketplace-webhook-admission'

export const MARKETPLACE_PAYMENT_WEBHOOK = "hobbysalon.marketplace_payment_webhook"

async function graph(container: any, entity: string, fields: string[], filters: any) {
  const { data } = await container.resolve(ContainerRegistrationKeys.QUERY).graph({ entity, fields, filters })
  return data
}
function invalid(message: string): never {
  throw new MedusaError(MedusaError.Types.INVALID_DATA, message)
}
export async function marketplacePaymentContext(container: any, input: any) {
  const id = input.data?.session_id
  if (!id) invalid("Payment webhook has no session binding")
  const sessions = await graph(container, "payment_session", ["id", "payment_collection_id", "provider_id", "amount", "currency_code", "data"], { id })
  if (sessions.length !== 1) invalid("Payment webhook session is unavailable; reconciliation required")
  const session = sessions[0]
  if (session.provider_id !== input.provider_id) invalid("Payment webhook provider/session mismatch")
  if (input.data.amount === undefined || !MathBN.eq(input.data.amount, session.amount)) invalid("Payment webhook amount/session mismatch")
  if (input.data.currency_code !== session.currency_code) invalid("Payment webhook currency/session mismatch")
  if (!input.data.payment_intent_id || session.data?.id !== input.data.payment_intent_id) invalid("Payment webhook intent/session mismatch")
  if (input.data.payment_collection_id && session.payment_collection_id !== input.data.payment_collection_id) invalid("Payment webhook collection changed since acceptance")
  const carts = await graph(container, "cart_payment_collection", ["cart_id"], { payment_collection_id: session.payment_collection_id })
  if (!carts.length) return { session, cart: null, orderSet: null }
  if (carts.length !== 1) invalid("Payment webhook cart binding is ambiguous")
  const cartRows = await graph(container, "cart", completeCartFields, { id: carts[0].cart_id })
  if (cartRows.length !== 1) invalid("Payment webhook cart is unavailable")
  if (input.data.cart_id && cartRows[0].id !== input.data.cart_id) invalid("Payment webhook cart changed since acceptance")
  const sets = await graph(container, "order_set", completedOrderSetFields, { cart_id: cartRows[0].id })
  if (sets.length > 1 || sets.some((s: any) => s.payment_collection_id !== session.payment_collection_id)) invalid("Payment webhook order-set binding is inconsistent")
  if (cartRows[0].completed_at && !sets.length) invalid("Completed marketplace cart has no order set; reconciliation required")
  const selected = cartRows[0].payment_collection?.payment_sessions?.find((s: any) => s.id === session.id)
  if (!selected || selected.status === 'captured') {
    // A second authenticated event action may follow a committed first event.
    // Completion validator accepts the same already-captured session selection.
    if (selected?.status !== 'captured') invalid('Payment session missing from cart collection')
  }
  return { session, cart: cartRows[0], orderSet: sets[0] ?? null }
}

export async function processMarketplacePaymentWebhook(container: any, input: any) {
  if (input?.provider_id !== 'pp_card_stripe-connect' || ![PaymentActions.AUTHORIZED, PaymentActions.SUCCESSFUL].includes(input.action)) invalid("Unsupported marketplace payment action/provider")
  if (!isCommercePaymentsEnabled()) invalid('Marketplace payments are disabled')
  const cartId = input.data?.cart_id
  if (!cartId) invalid('Payment webhook has no accepted cart binding')
  return withCommerceCartLock(container, cartId, async () => {
    // PG_CONNECTION is Knex for advisory locks, NOT an ORM manager. Native
    // payment repository supplies the root MikroORM boundary for all modules.
    const payment = container.resolve('payment')
    const manager = payment?.baseRepository_?.manager_
    if (!manager?.fork || !manager?.transactional || !manager?.execute) invalid('Native payment root manager unavailable')
    const root = manager.fork({ clear: true, useContext: false })
    if (await readCommittedMarketplaceWebhookReceipt(root, input)) return { duplicate: true }
    assertMarketplaceCompletionHooksSupported()
    const { session, cart, orderSet } = await marketplacePaymentContext(container, input)
    if (!cart || cart.id !== cartId) invalid('Marketplace cart binding changed')
    const expected = { session_id: input.data.session_id, collection_id: session.payment_collection_id,
      intent_id: input.data.payment_intent_id, amount: input.data.amount, currency_code: input.data.currency_code }
    assertExpectedCartPayment(cart, cart.payment_collection?.payment_sessions ?? [], expected, cartId)
    if (orderSet) assertCompletedCartOrderSet(cart, [orderSet], cartId, expected)
    if (typeof payment.prepareMarketplaceWebhookCapture_ !== 'function') invalid('Marketplace provider preparation unavailable')
    // Both accepted card event actions finish the same first-flow full capture.
    // Preparation reads live status; already-succeeded intents never redispatch.
    // Durable admission before any irreversible provider preparation. Not a success receipt.
    await persistMarketplaceWebhookAdmission(root,input)
    assertCommerceFinancialLock()
    const prepared = await payment.prepareMarketplaceWebhookCapture_({ cart_id: cartId, cart, expected, action: input.action })
    // Preparation can revoke financial authority even if a native adapter returns.
    // Do not begin a physical apply transaction after that irreversible failure.
    assertCommerceFinancialLock()
    assertMarketplaceCompletionHooksSupported()
    return applyMarketplaceWebhookTransaction(root, input, scope => completeMarketplaceWebhookDb(scope, container,
      { cart, expected_payment: expected, prepared_capture: prepared, event_id: input.event_id }))
  })
}
