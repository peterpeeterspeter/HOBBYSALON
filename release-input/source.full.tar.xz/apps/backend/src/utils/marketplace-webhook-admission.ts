import type { MarketplaceWebhookIdentity } from './marketplace-webhook-transaction'
import { marketplaceWebhookFingerprint } from './marketplace-webhook-transaction'

/** Authenticated accepted identity, committed BEFORE provider preparation. A receipt
 * means completed business apply, an admission does not. No historical backfill. */
export async function persistMarketplaceWebhookAdmission(manager: any, input: MarketplaceWebhookIdentity): Promise<void> {
  const fingerprint = marketplaceWebhookFingerprint(input)
  const snapshot = JSON.parse(JSON.stringify(input))
  if (manager.getTransactionContext()) throw new Error('Webhook admission requires root storage')
  await manager.transactional(async (owner: any) => {
    const tx = owner.getTransactionContext()
    const check = () => { if (!tx?.isTransaction || !tx.client?.transacting || owner.getTransactionContext() !== tx) throw new Error('Native admission transaction unavailable') }
    check()
    await owner.execute('SET LOCAL synchronous_commit = on'); check()
    await owner.execute(`INSERT INTO marketplace_webhook_admission (event_id,fingerprint,cart_id,session_id,input)
      VALUES (?,?,?,?,?::jsonb) ON CONFLICT (event_id) DO NOTHING`,
      [snapshot.event_id,fingerprint,snapshot.data.cart_id,snapshot.data.session_id,JSON.stringify(snapshot)])
    check()
    const rows = await owner.execute('SELECT fingerprint,input,cart_id,session_id FROM marketplace_webhook_admission WHERE event_id=?',[snapshot.event_id])
    check()
    if (!Array.isArray(rows) || rows.length !== 1 || rows[0].fingerprint !== fingerprint ||
        rows[0].cart_id !== snapshot.data.cart_id || rows[0].session_id !== snapshot.data.session_id ||
        marketplaceWebhookFingerprint(rows[0].input) !== fingerprint) throw new Error('Webhook admission identity collision')
  },{clear:true})
}
