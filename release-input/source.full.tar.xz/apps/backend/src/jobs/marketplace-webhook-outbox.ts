import type { MedusaContainer } from '@medusajs/framework/types'
import { runMarketplaceWebhookOutboxTransport } from '../utils/marketplace-webhook-outbox'

/** Candidate opt-in transport only; no consumer ACK or financial retry. */
export default async function marketplaceWebhookOutboxJob(container: MedusaContainer): Promise<void> {
  await runMarketplaceWebhookOutboxTransport(container)
}
export const config = { name: 'marketplace-webhook-outbox', schedule: '*/5 * * * *' }
