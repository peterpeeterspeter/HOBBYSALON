import type { MedusaContainer } from '@medusajs/framework/types'
import { ContainerRegistrationKeys } from '@medusajs/framework/utils'
import { replayMarketplaceWebhookAdmission } from '../utils/marketplace-webhook-replay'
/** Private reconciliation is explicitly disabled until real PG/app gates pass. */
export default async function marketplaceWebhookReplayJob(container: MedusaContainer): Promise<void> {
  if (process.env.COMMERCE_WEBHOOK_REPLAY_ENABLED !== 'true') return
  const pg = container.resolve(ContainerRegistrationKeys.PG_CONNECTION)
  const {rows} = await pg.raw(`SELECT a.event_id FROM marketplace_webhook_admission a
    JOIN marketplace_capture_tail t ON t.cart_id=a.cart_id
    LEFT JOIN marketplace_webhook_replay_attempt x ON x.event_id=a.event_id
    LEFT JOIN marketplace_stripe_event_receipt r ON r.event_id=a.event_id
    WHERE r.event_id IS NULL AND t.snapshot->>'protocol'='atomic-stripe-event'
    AND (x.last_attempt_at IS NULL OR x.last_attempt_at<now()-interval '5 minutes')
    ORDER BY x.last_attempt_at NULLS FIRST,a.created_at,a.event_id LIMIT 20`)
  if (!Array.isArray(rows)) throw new Error('Atomic webhook replay candidates unavailable')
  for (const row of rows) {
    try { await replayMarketplaceWebhookAdmission(container,row.event_id) }
    catch { container.resolve(ContainerRegistrationKeys.LOGGER).warn('Atomic webhook replay deferred; immutable binding or succeeded capture unavailable') }
  }
}
export const config = {name:'marketplace-webhook-replay',schedule:'*/5 * * * *'}
