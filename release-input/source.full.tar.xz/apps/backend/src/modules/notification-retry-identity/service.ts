import NativeNotificationModule from '@medusajs/notification'
import type { Context, NotificationTypes } from '@medusajs/framework/types'
import { NotificationStatus } from '@medusajs/framework/utils'
// Persisted protocol values, checked against the actual Resend template enum in
// source-bound integration tests. Do not import another package's raw source
// from this app module: packaged runtime boundaries must remain intact.
const orderEmailTemplates = {
  buyer: 'buyerNewOrderEmailTemplate',
  seller: 'sellerNewOrderEmailTemplate',
} as const

type OrderEffectDescriptor = {
  key: string
  to: string
  channel: string
  template: string
  orderId?: string
  title?: string
  description?: string
  redirect?: string
}

const invalidOutcome = () => new Error('Order notification outcome: invalid or uncertain notification evidence')
const nonblank = (value: unknown): value is string => typeof value === 'string' && !!value.trim()
const object = (value: unknown): value is Record<string, unknown> =>
  value !== null && typeof value === 'object' && !Array.isArray(value)

// Compare only typed stable fields, not prototypes, serialized object order, or
// full rendering payload. Native stores data, but has no content model column.
function orderDescriptor(value: unknown): OrderEffectDescriptor {
  if (!object(value) || !nonblank(value.idempotency_key) || !object(value.data)) throw invalidOutcome()
  const key = value.idempotency_key
  const separator = key.indexOf(':')
  const kind = key.slice(0, separator)
  const identity = key.slice(separator + 1)
  if (separator < 0 || !nonblank(identity) || identity.includes(':')) throw invalidOutcome()
  let channel: string, template: string
  switch (kind) {
    case 'buyer-new-order':
      channel = 'email'; template = orderEmailTemplates.buyer; break
    case 'seller-new-order':
      channel = 'email'; template = orderEmailTemplates.seller; break
    case 'seller-new-order-feed':
      channel = 'seller_feed'; template = 'seller_new_order_notification'; break
    case 'admin-new-order-set-feed':
      channel = 'feed'; template = 'admin-ui'; break
    default: throw invalidOutcome()
  }
  if (value.channel !== channel || value.template !== template ||
      (channel === 'feed' ? value.to !== '' : !nonblank(value.to))) throw invalidOutcome()
  const descriptor: OrderEffectDescriptor = { key, to: value.to as string, channel, template }
  if (channel === 'feed') {
    // The existing admin payload has no order_id; set identity is in the key.
    const { title, description, redirect } = value.data
    if (title !== 'New order set placed' ||
        description !== 'Someone has placed a new order from multiple sellers 🔔' ||
        redirect !== '/admin/orders') throw invalidOutcome()
    return { ...descriptor, title, description, redirect }
  }
  // Actual email handlers persist entry.data.data; feeds use entry.data.
  // The distinction survives native serialization and must not be flattened.
  const payload = channel === 'email' ? value.data.data : value.data
  if (!object(payload) || payload.order_id !== identity ||
      (channel === 'email' && (!object(payload.order) || payload.order.id !== identity))) throw invalidOutcome()
  return { ...descriptor, orderId: identity }
}

function sameDescriptor(left: OrderEffectDescriptor, right: OrderEffectDescriptor) {
  return left.key === right.key && left.to === right.to && left.channel === right.channel &&
    left.template === right.template && left.orderId === right.orderId && left.title === right.title &&
    left.description === right.description && left.redirect === right.redirect
}

/** Medusa 2.11.3 identity-only workaround; delivery/skip/update stay native.
 * No lock or claim: concurrent retries and uncertain pending recovery remain gates.
 */
export default class NotificationRetryIdentityService extends NativeNotificationModule.service {
  /** Bounded status readback, NOT commit/provider acceptance/ACK/concurrency proof.
   * No ambient transaction authority is inferred; preflight/readback are not a
   * lock. Native batch dispatch has a TOCTOU window and may partially succeed.
   */
  async createOrderNotifications(data: NotificationTypes.CreateNotificationDTO | NotificationTypes.CreateNotificationDTO[]) {
    const entries = Array.isArray(data) ? data : [data]
    if (!entries.length || entries.length > 100) throw invalidOutcome()
    const expected = new Map<string, OrderEffectDescriptor>()
    const explicitIds = new Map<string, string>()
    // Use for..of so sparse arrays cannot evade validation.
    for (const entry of entries) {
      const descriptor = orderDescriptor(entry)
      if (expected.has(descriptor.key)) throw invalidOutcome()
      expected.set(descriptor.key, descriptor)
      if ('id' in entry) {
        if (!nonblank(entry.id)) throw invalidOutcome()
        explicitIds.set(descriptor.key, entry.id)
      }
    }
    const keys = [...expected.keys()]
    const read = async (complete: boolean, previous = new Map<string, string>()) => {
      // Public generated list serializes native rows. Include tombstones and one
      // extra row so deletion/overflow cannot masquerade as clean evidence.
      const rows = await this.listNotifications({ idempotency_key: keys }, { take: keys.length + 1, withDeleted: true })
      if (!Array.isArray(rows) || rows.length > keys.length) throw invalidOutcome()
      const seenIds = new Set<string>()
      const identities = new Map<string, string>()
      for (const candidate of rows) {
        const row = candidate as unknown as Record<string, unknown>
        if (!object(row) || !nonblank(row.id) || !nonblank(row.idempotency_key) ||
            !expected.has(row.idempotency_key) || identities.has(row.idempotency_key) ||
            seenIds.has(row.id) || row.deleted_at != null) throw invalidOutcome()
        const descriptor = orderDescriptor(row)
        if (!sameDescriptor(expected.get(descriptor.key)!, descriptor) ||
            (explicitIds.has(descriptor.key) && explicitIds.get(descriptor.key) !== row.id) ||
            (previous.has(descriptor.key) && previous.get(descriptor.key) !== row.id)) throw invalidOutcome()
        if (row.status !== NotificationStatus.SUCCESS && row.status !== NotificationStatus.FAILURE) throw invalidOutcome()
        if (complete && row.status !== NotificationStatus.SUCCESS) throw invalidOutcome()
        if (row.status === NotificationStatus.SUCCESS && descriptor.channel === 'email' && !nonblank(row.external_id)) throw invalidOutcome()
        identities.set(descriptor.key, row.id)
        seenIds.add(row.id)
      }
      if (complete && identities.size !== keys.length) throw invalidOutcome()
      for (const key of explicitIds.keys()) if (!identities.has(key)) throw invalidOutcome()
      return identities
    }
    const before = await read(false)
    // Public inherited method preserves normalization, decorators, serialization
    // and scalar/array return. The generic FAILURE-ID workaround remains intact.
    const result = await this.createNotifications(data)
    await read(true, before)
    return result
  }

  protected async createNotifications_(
    data: NotificationTypes.CreateNotificationDTO[],
    sharedContext: Context = {}
  ) {
    const keys = data.map((entry) => entry.idempotency_key).filter(Boolean) as string[]
    if (!keys.length) return super.createNotifications_(data, sharedContext)

    // Native batches cannot safely distinguish two entries with the same key.
    if (new Set(keys).size !== keys.length) {
      throw new Error('Notification retry identity: duplicate input idempotency key')
    }
    // One extra result suffices to detect ambiguous stored identities, without
    // silently accepting the internal service's default page size.
    const records = await this.notificationService_.list(
      { idempotency_key: keys },
      { take: keys.length + 1 },
      sharedContext
    )
    const byKey = new Map<string, (typeof records)[number]>()
    for (const record of records) {
      if (!record.id || !record.idempotency_key || !keys.includes(record.idempotency_key)) {
        throw new Error('Notification retry identity: missing or invalid persisted identity')
      }
      if (byKey.has(record.idempotency_key)) {
        throw new Error('Notification retry identity: duplicate persisted idempotency key')
      }
      byKey.set(record.idempotency_key, record)
    }
    const normalized = data.map((entry) => {
      if (!entry.idempotency_key) return entry
      const persisted = byKey.get(entry.idempotency_key)
      // A new key is an initial delivery, not a historical retry. An explicit
      // retry identity without its row must not silently create another row.
      if (!persisted && 'id' in entry) {
        throw new Error('Notification retry identity: explicit identity has no persisted record')
      }
      // Leave native pending/success skips untouched, and never mutate the DTO.
      return persisted?.status === NotificationStatus.FAILURE
        ? { ...entry, id: persisted.id }
        : entry
    })
    return super.createNotifications_(normalized, sharedContext)
  }
}
