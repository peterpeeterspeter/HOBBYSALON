import { asValue } from '@medusajs/framework/awilix'
import Provider from './provider'
export default async function loader({ container }: any) {
  container.register('storageProviderCtr', asValue(Provider))
}