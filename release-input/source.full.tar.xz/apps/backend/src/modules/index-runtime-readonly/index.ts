import NativeIndexModule from '@medusajs/index'
import * as nativeModels from '@medusajs/index/dist/models'
import * as nativeServices from '@medusajs/index/dist/services'
import { Modules, ModulesSdkUtils, toMikroOrmEntities } from '@medusajs/framework/utils'
import { dirname, join } from 'node:path'
import service from './service'
import loader from './loader'

const nativeDirectory = dirname(require.resolve('@medusajs/index'))
const models = toMikroOrmEntities(Object.values(nativeModels))
const moduleModels = Object.fromEntries(models.map(model => [model.name, model]))
const migrationOptions = { moduleName: Modules.INDEX, pathToMigrations: join(nativeDirectory, 'migrations') }
export default {
  ...NativeIndexModule,
  service,
  loaders: [
    ModulesSdkUtils.mikroOrmConnectionLoaderFactory({ moduleName: Modules.INDEX, moduleModels: models, migrationsPath: migrationOptions.pathToMigrations }),
    ModulesSdkUtils.moduleContainerLoaderFactory({ moduleModels, moduleServices: nativeServices }),
    ...(NativeIndexModule.loaders ?? []), loader
  ],
  runMigrations: ModulesSdkUtils.buildMigrationScript(migrationOptions),
  revertMigration: ModulesSdkUtils.buildRevertMigrationScript(migrationOptions),
  generateMigration: ModulesSdkUtils.buildGenerateMigrationScript({ ...migrationOptions, models })
}