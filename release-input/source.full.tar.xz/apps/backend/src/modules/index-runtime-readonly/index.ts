import NativeIndexModule from '@medusajs/index'
import * as nativeModels from '@medusajs/index/dist/models'
import * as nativeServices from '@medusajs/index/dist/services'
import { DataSynchronizer } from '@medusajs/index/dist/services/data-synchronizer'
import { IndexDataService } from '@medusajs/index/dist/services/index-data'
import { IndexMetadataService } from '@medusajs/index/dist/services/index-metadata'
import { IndexRelationService } from '@medusajs/index/dist/services/index-relation'
import { IndexSyncService } from '@medusajs/index/dist/services/index-sync'
import { PostgresProvider } from '@medusajs/index/dist/services/postgres-provider'
import { Modules, ModulesSdkUtils, toMikroOrmEntities } from '@medusajs/framework/utils'
import { dirname, join } from 'node:path'
import service from './service'
import loader from './loader'

const nativeDirectory = dirname(require.resolve('@medusajs/index'))
const models = toMikroOrmEntities(Object.values(nativeModels))
const moduleModels = Object.fromEntries(models.map(model => [model.name, model]))
const migrationOptions = { moduleName: Modules.INDEX, pathToMigrations: join(nativeDirectory, 'migrations') }
// Our named containerLoader suppresses SDK service-directory discovery. Restore
// that exact native resource map, not just the public IndexModuleService barrel.
// Native singleton aliases (notably dataSynchronizer) remain lazy; the final
// readonly loader still replaces storageProviderCtr before service construction.
const moduleServices = { ...nativeServices, DataSynchronizer, IndexDataService, IndexMetadataService, IndexRelationService, IndexSyncService, PostgresProvider }
export default {
  ...NativeIndexModule,
  service,
  loaders: [
    ModulesSdkUtils.mikroOrmConnectionLoaderFactory({ moduleName: Modules.INDEX, moduleModels: models, migrationsPath: migrationOptions.pathToMigrations }),
    ModulesSdkUtils.moduleContainerLoaderFactory({ moduleModels, moduleServices }),
    ...(NativeIndexModule.loaders ?? []), loader
  ],
  runMigrations: ModulesSdkUtils.buildMigrationScript(migrationOptions),
  revertMigration: ModulesSdkUtils.buildRevertMigrationScript(migrationOptions),
  generateMigration: ModulesSdkUtils.buildGenerateMigrationScript({ ...migrationOptions, models })
}