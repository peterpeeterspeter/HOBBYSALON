import { createPartitions } from '@medusajs/index/dist/utils/create-partitions'

const identifier = /^[A-Za-z_][A-Za-z0-9_]*$/
const compact = (v: string) => v.replace(/[\s"]/g, '').toLowerCase()
export async function nativePlan(schemaObject: any, schema: string) {
  if (!identifier.test(schema)) throw new Error('INDEX_INVALID_SCHEMA')
  for (const [key, value] of Object.entries(schemaObject) as any) {
    if (key.startsWith('_')) continue
    if (!identifier.test(key) || value.parents?.some((p: any) => !identifier.test(p.ref.entity))) throw new Error('INDEX_UNSAFE_ENTITY')
  }
  const sql: string[] = []
  await createPartitions(schemaObject, { config: { get: () => schema }, execute: async (q: string) => { sql.push(q) } } as any)
  const partitions: any[] = [], indexes: any[] = []
  const text = sql.join('; ')
  for (const m of text.matchAll(/CREATE TABLE IF NOT EXISTS "[^"]+"\.(\w+) PARTITION OF "[^"]+"\.(\w+) FOR VALUES IN \('([^']+)'\)/g)) {
    if (!partitions.some(p => p.name === m[1])) partitions.push({ name: m[1], parent: m[2], bound: m[3] })
  }
  for (const m of text.matchAll(/CREATE INDEX CONCURRENTLY IF NOT EXISTS "([^"]+)" ON "[^"]+"\.(\w+) (?:USING (GIN) )?\("([^"]+)"(?: (jsonb_path_ops))?\)/g)) {
    if (!indexes.some(i => i.name === m[1])) indexes.push({ name: m[1], table: m[2], method: m[3] ? 'gin' : 'btree', key: m[4] + (m[5] ? ' ' + m[5] : '') })
  }
  if (!partitions.length || !indexes.length) throw new Error('INDEX_EMPTY_OR_UNSUPPORTED_NATIVE_PLAN')
  const body = text.match(/RETURNS bigint AS \$\$([\s\S]*?)\$\$ LANGUAGE plpgsql/)
  if (!body) throw new Error('INDEX_UNSUPPORTED_NATIVE_FUNCTION')
  return { partitions, indexes, body: body[1] }
}

// Only SELECTs reach the real manager. Native DDL above is captured, never sent.
export async function verifyCatalog(manager: any, schemaObject: any) {
  const [session] = await manager.execute('SELECT current_schema() AS schema')
  const schema = manager.config.get('schema') || session?.schema
  if (!schema || session?.schema !== schema) throw new Error('INDEX_SCHEMA_SEARCH_PATH_MISMATCH')
  const plan = await nativePlan(schemaObject, schema)
  const partitions = await manager.execute(`SELECT c.relname AS name, p.relname AS parent, pn.nspname AS parent_schema,
    c.relispartition AS is_partition, p.relkind AS parent_kind, pg_catalog.pg_table_is_visible(c.oid) AS visible,
    pg_catalog.pg_get_expr(c.relpartbound, c.oid) AS bound
    FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace
    JOIN pg_catalog.pg_inherits h ON h.inhrelid=c.oid JOIN pg_catalog.pg_class p ON p.oid=h.inhparent
    JOIN pg_catalog.pg_namespace pn ON pn.oid=p.relnamespace WHERE n.nspname=?`, [schema])
  for (const p of plan.partitions) {
    const row = partitions.find((r: any) => r.name === p.name)
    if (!row || row.parent !== p.parent || row.parent_schema !== schema || row.parent_kind !== 'p' || row.is_partition !== true || row.visible !== true || compact(row.bound) !== compact(`FOR VALUES IN ('${p.bound}')`)) throw new Error(`INDEX_INVALID_PARTITION:${p.name}`)
  }
  const indexes = await manager.execute(`SELECT i.relname AS name, t.relname AS table_name, am.amname AS method,
    x.indisvalid AS valid, x.indisready AS ready, x.indisunique AS is_unique, x.indnkeyatts AS key_count,
    x.indnatts AS attribute_count, x.indpred IS NULL AS no_predicate, x.indexprs IS NULL AS no_expression,
    pg_catalog.pg_get_indexdef(i.oid, 1, true) AS key
    FROM pg_catalog.pg_index x JOIN pg_catalog.pg_class i ON i.oid=x.indexrelid
    JOIN pg_catalog.pg_class t ON t.oid=x.indrelid JOIN pg_catalog.pg_namespace n ON n.oid=t.relnamespace
    JOIN pg_catalog.pg_am am ON am.oid=i.relam WHERE n.nspname=?`, [schema])
  for (const i of plan.indexes) {
    const row = indexes.find((r: any) => r.name === i.name)
    if (!row || row.table_name !== i.table || row.method !== i.method || row.valid !== true || row.ready !== true || row.is_unique !== false || row.key_count !== 1 || row.attribute_count !== 1 || row.no_predicate !== true || row.no_expression !== true || compact(row.key) !== compact(i.key)) throw new Error(`INDEX_INVALID_INDEX:${i.name}`)
  }
  const functions = await manager.execute(`SELECT p.prosrc AS body, p.prosecdef AS security_definer, l.lanname AS language,
    pg_catalog.pg_get_function_result(p.oid) AS result, p.proconfig AS config,
    p.oid = pg_catalog.to_regprocedure('count_estimate(text)') AS visible
    FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace
    JOIN pg_catalog.pg_language l ON l.oid=p.prolang
    WHERE n.nspname=? AND p.proname='count_estimate' AND pg_catalog.pg_get_function_identity_arguments(p.oid)='query text'`, [schema])
  if (!functions.some((f: any) => f.visible === true && f.security_definer === false && f.language === 'plpgsql' && f.result === 'bigint' && f.config == null && compact(f.body) === compact(plan.body))) throw new Error('INDEX_INVALID_COUNT_ESTIMATE')
  return { schema, plan }
}

export async function bootstrapNativeIndex(manager: any, schemaObject: any, authorization: { approved: boolean, migratorRole: string }) {
  if (authorization.approved !== true || !identifier.test(authorization.migratorRole)) throw new Error('INDEX_MIGRATOR_APPROVAL_REQUIRED')
  const [identity] = await manager.execute('SELECT current_user AS role, current_schema() AS schema, current_setting(\'search_path\') AS search_path')
  if (identity.role !== authorization.migratorRole || identity.schema !== manager.config.get('schema')) throw new Error('INDEX_MIGRATOR_ROLE_OR_SCHEMA_MISMATCH')
  await nativePlan(schemaObject, identity.schema)
  // Native function is unqualified: pin its creation to the approved schema.
  await manager.execute("SELECT set_config('search_path', ?, false)", [`"${identity.schema}"`])
  try {
    await createPartitions(schemaObject, manager)
    // Native index creation catches errors: postconditions make this fail closed.
    await verifyCatalog(manager, schemaObject)
  } finally {
    await manager.execute("SELECT set_config('search_path', ?, false)", [identity.search_path])
  }
}