import { PostgresProvider } from '@medusajs/index/dist/services/postgres-provider'
import { verifyCatalog } from './catalog'

export default class ReadonlyBootstrapPostgresProvider extends PostgresProvider {
  private readiness: Promise<void>
  private resolveReady!: () => void
  private rejectReady!: (error: any) => void
  private startup?: Promise<void>
  readonlyBootstrapReady = false
  constructor(...args: ConstructorParameters<typeof PostgresProvider>) {
    super(...args)
    this.readiness = new Promise((resolve, reject) => { this.resolveReady = resolve; this.rejectReady = reject })
    // Observe rejection even when no subscriber/query is waiting yet.
    void this.readiness.catch(() => {})
  }
  onApplicationStart(): Promise<void> {
    if (!this.startup) this.startup = (async () => {
      try {
        await verifyCatalog(this.manager_.fork(), this.schemaObjectRepresentation_)
        this.readonlyBootstrapReady = true
        this.resolveReady()
      } catch (error) { this.rejectReady(error); throw error }
    })()
    return this.startup
  }
  // Native #isReady_ remains undefined intentionally; every externally callable
  // data entry is gated by our real promise before invoking the decorated native
  // method. Calling super.onApplicationStart() would execute runtime DDL.
  consumeEvent(schema: any) { const native = super.consumeEvent(schema); return async (event: any) => { await this.readiness; return native(event) } }
  async query(config: any, context: any = {}) { await this.readiness; return super.query(config, context) }
  async onCreate(input: any, context: any = {}) { await this.readiness; return super.onCreate(input, context) }
  async onUpdate(input: any, context: any = {}) { await this.readiness; return super.onUpdate(input, context) }
  async onDelete(input: any, context: any = {}) { await this.readiness; return super.onDelete(input, context) }
  async onAttach(input: any, context: any = {}) { await this.readiness; return super.onAttach(input, context) }
  async onDetach(input: any, context: any = {}) { await this.readiness; return super.onDetach(input, context) }
}