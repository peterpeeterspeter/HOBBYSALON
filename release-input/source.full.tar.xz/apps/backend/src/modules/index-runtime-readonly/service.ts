import { IndexModuleService } from '@medusajs/index/dist/services'

type NativeConstructor = ConstructorParameters<typeof IndexModuleService>
type StartupErrorSink = { failed: boolean; error: unknown; complete: boolean }

export default class ReadonlyBootstrapIndexService extends IndexModuleService {
  private readonly startupErrorSink: StartupErrorSink
  private readonly runtimeManager: unknown

  constructor(container: NativeConstructor[0], moduleOptions: NativeConstructor[1], moduleDeclaration: NativeConstructor[2]) {
    const sink: StartupErrorSink = { failed: false, error: undefined, complete: false }
    // Preserve lazy Awilix resolution and the native console fallback. Never
    // override the native private logger_ getter or mutate the shared container.
    const wrappedContainer = new Proxy(container, {
      get(target, key) {
        if (key !== 'logger') return Reflect.get(target, key, target)
        const logger = (() => { try { return target.logger } catch { return console } })()
        return new Proxy(logger, {
          get(loggerTarget, loggerKey) {
            if (loggerKey === 'error') return (...args: Parameters<NativeConstructor[0]['logger']['error']>) => {
              if (!sink.complete && !sink.failed) { sink.failed = true; sink.error = args[0] }
              return loggerTarget.error(...args)
            }
            const value = Reflect.get(loggerTarget, loggerKey, loggerTarget)
            return typeof value === 'function' ? value.bind(loggerTarget) : value
          }
        })
      }
    })
    super(wrappedContainer, moduleOptions, moduleDeclaration)
    this.startupErrorSink = sink
    this.runtimeManager = Reflect.get(container, 'manager', container)
  }

  async onApplicationStart_(): Promise<void> {
    let timer: ReturnType<typeof setTimeout> | undefined
    try {
      await Promise.race([
        (async () => {
          await super.onApplicationStart_()
          if (this.startupErrorSink.failed) throw this.startupErrorSink.error
          const provider = this.storageProvider_
          if (!provider || !('readonlyBootstrapReady' in provider) || !provider.readonlyBootstrapReady) throw new Error('INDEX_STARTUP_NOT_READY')
          const manager = this.runtimeManager
          if (!manager || typeof manager !== 'object' || !('fork' in manager) || typeof manager.fork !== 'function') throw new Error('INDEX_STARTUP_QUERY_FAILED')
          const fork: unknown = manager.fork()
          if (!fork || typeof fork !== 'object' || !('execute' in fork) || typeof fork.execute !== 'function') throw new Error('INDEX_STARTUP_QUERY_FAILED')
          const rows: unknown = await fork.execute("SELECT count_estimate('SELECT 1') AS estimate")
          const row: unknown = Array.isArray(rows) ? rows[0] : undefined
          if (!row || typeof row !== 'object' || !('estimate' in row) || row.estimate == null || !Number.isFinite(Number(row.estimate))) throw new Error('INDEX_STARTUP_QUERY_FAILED')
          if (this.startupErrorSink.failed) throw this.startupErrorSink.error
          this.startupErrorSink.complete = true
        })(),
        new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error('INDEX_STARTUP_TIMEOUT')), 30000) })
      ])
    } finally { if (timer) clearTimeout(timer) }
  }
}
