import { IndexModuleService } from '@medusajs/index/dist/services'

export default class ReadonlyBootstrapIndexService extends IndexModuleService {
  private startupFailure: any
  private startupComplete = false
  get logger_(): any {
    const logger = super.logger_
    return new Proxy(logger, { get: (target, key) => key === 'error' ? (error: any) => { if (!this.startupComplete) this.startupFailure = error; target.error(error) } : typeof target[key] === 'function' ? target[key].bind(target) : target[key] })
  }
  async onApplicationStart_(): Promise<void> {
    let timer: ReturnType<typeof setTimeout> | undefined
    try {
      await Promise.race([
        (async () => {
          await super.onApplicationStart_()
          if (this.startupFailure) throw this.startupFailure
          const provider = (this as any).storageProvider_
          if (!provider?.readonlyBootstrapReady) throw new Error('INDEX_STARTUP_NOT_READY')
          const [row] = await (this as any).container_.manager.fork().execute("SELECT count_estimate('SELECT 1') AS estimate")
          if (!row || row.estimate == null || !Number.isFinite(Number(row.estimate))) throw new Error('INDEX_STARTUP_QUERY_FAILED')
          this.startupComplete = true
        })(),
        new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error('INDEX_STARTUP_TIMEOUT')), 30000) })
      ])
    } finally { if (timer) clearTimeout(timer) }
  }
}