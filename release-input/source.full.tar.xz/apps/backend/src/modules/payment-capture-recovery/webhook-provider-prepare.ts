import { Collection } from '@medusajs/framework/mikro-orm/core'
import { BigNumber, MathBN, MedusaError, PaymentSessionStatus } from '@medusajs/framework/utils'
import type { Context } from '@medusajs/framework/types'
import { getAmountFromSmallestUnit, getSmallestUnit } from '@mercurjs/framework'
import { assertExpectedCartPayment, ExpectedCartPayment } from '@mercurjs/b2c-core/utils/expected-cart-payment'
import { assertCommerceSessionLock } from '@mercurjs/b2c-core/utils/commerce-financial-lock'
import { assertCommerceFinancialLock, assertCommercePaymentLock, commerceFinancialLockQuery, revokeCommerceFinancialWork } from '@mercurjs/b2c-core/utils/commerce-cart-lock'
import { assertRefundEffectFenceIfPresent } from '@mercurjs/b2c-core/utils/refund-effect-fence'
import { assertCommerceRefundQuarantineClear } from '@mercurjs/b2c-core/utils/commerce-refund-quarantine'
import type { PreparedMarketplaceCapture } from '../../utils/marketplace-webhook-finalization'

/** Internal server-only input. cart is the fresh native validated cart, never an HTTP body.
 * This protocol does not authorize completion; the DB-only caller still validates
 * its immutable order/allocations snapshot and all bindings under the same lock.
 */
export interface MarketplaceWebhookPrepareInput {
  action?: string
  /** Private reconciliation: read existing reservation/status only, NEVER dispatch. */
  recovery_only?: boolean
  reservation?: {payment_id:string;capture_id:string}
  cart_id: string
  cart: { id: string; currency_code: string; total: any; payment_collection: { id: string } }
  expected: ExpectedCartPayment
}
export type PreparedWebhookProviderCapture = Omit<PreparedMarketplaceCapture, 'allocations'> & {
  readonly phase: 'PREPARED'
  readonly session_id: string
  readonly provider_id: string
  readonly intent_id: string
  readonly currency_code: string
  readonly amount: string
  readonly minor_amount: number
  readonly allocations: readonly PreparedMarketplaceCapture['allocations'][number][]
}
const fail = (reason: string): never => { throw new MedusaError(MedusaError.Types.INVALID_DATA, `Webhook capture preparation: ${reason}`) }
const valid = (id: unknown): id is string => typeof id === 'string' && !!id && id.length <= 255 && id.trim() === id && !/[\u0000-\u001f\u007f]/.test(id)
export function assertWebhookPrepareFence(): void { assertCommerceFinancialLock(); assertRefundEffectFenceIfPresent() }
function rawAmount(row: any): BigNumber {
  if (!row?.raw_amount || !['string', 'number'].includes(typeof row.raw_amount.value)) return fail('invalid native amount')
  const n = new BigNumber(row.raw_amount.value)
  if (!n.bigNumber?.isFinite() || !MathBN.gt(n, 0) || !MathBN.eq(row.amount, n)) return fail('inconsistent native amount')
  return n
}
function rawAmountString(row: unknown): string {
  const decimal = rawAmount(row).bigNumber
  if (!decimal || !decimal.isFinite()) return fail('inconsistent native amount')
  return decimal.toString()
}
/** Copy before every ownership/provider await. Reject non-JSON, cycles, accessors,
 * sparse arrays and exotic objects; freezing just the outer receipt is insufficient.
 */
export function immutableWebhookJson(value: any, ancestors = new Set<object>()): any {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (!value || typeof value !== 'object' || ancestors.has(value) ||
      (!Array.isArray(value) && ![Object.prototype, null].includes(Object.getPrototypeOf(value)))) return fail('provider data is not immutable JSON')
  ancestors.add(value)
  const out: any = Array.isArray(value) ? [] : Object.create(null)
  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i++) {
      const descriptor = Object.getOwnPropertyDescriptor(value, String(i))
      if (!descriptor || !('value' in descriptor)) return fail('invalid provider array')
      out.push(immutableWebhookJson(descriptor.value, ancestors))
    }
  } else {
    for (const key of Reflect.ownKeys(value)) {
      if (typeof key !== 'string') return fail('invalid provider data key')
      const descriptor = Object.getOwnPropertyDescriptor(value, key)!
      if (!('value' in descriptor)) return fail('provider data accessor')
      out[key] = immutableWebhookJson(descriptor.value, ancestors)
    }
  }
  ancestors.delete(value)
  return Object.freeze(out)
}
function captures(payment: any): any[] {
  const c = payment.captures
  const rows = Array.isArray(c) ? c : c instanceof Collection && c.isInitialized(true) ? c.getItems() : fail('capture relation not initialized')
  if (rows.length > 1) return fail('ambiguous capture reservations')
  return rows
}
export function validateWebhookCaptureReservation(payment: any, expected: ExpectedCartPayment): any | undefined {
  if (!valid(payment?.id) || payment.provider_id !== 'pp_card_stripe-connect' ||
      payment.payment_collection_id !== expected.collection_id || payment.data?.id !== expected.intent_id ||
      payment.currency_code !== expected.currency_code || !MathBN.eq(rawAmount(payment), expected.amount) || payment.canceled_at) return fail('payment binding changed')
  const rows = captures(payment), row = rows[0]
  if (rows.length && (!row || !valid(row.id) ||
      (row.payment_id !== undefined && row.payment_id !== payment.id) ||
      (row.payment != null && row.payment.id !== payment.id) || !MathBN.eq(rawAmount(row), expected.amount))) return fail('invalid full capture reservation')
  if (payment.captured_at && !row) return fail('captured payment lacks reservation')
  return row
}
function verifyReceipt(value: any, expected: ExpectedCartPayment, minor: number, allowAuthorized: boolean): Record<string, unknown> {
  const receipt = immutableWebhookJson(value)
  if (receipt.id !== expected.intent_id || receipt.currency !== expected.currency_code || receipt.amount !== minor) return fail('receipt binding mismatch')
  if (receipt.status === 'succeeded') {
    if (receipt.amount_received !== minor || receipt.amount_capturable !== 0) return fail('receipt does not prove exact full capture')
  } else if (allowAuthorized && receipt.status === 'requires_capture') {
    if (receipt.amount_received !== 0 || receipt.amount_capturable !== minor) return fail('partial authorization')
  } else return fail('provider state not safely capturable')
  return receipt
}
/** Structural internal receiver only; never export this as a public module API. */
export async function prepareWebhookProviderCapture(service: any, input: MarketplaceWebhookPrepareInput, context: Context = {}): Promise<PreparedWebhookProviderCapture> {
  try {
    assertWebhookPrepareFence()
    if (context.transactionManager !== undefined) return fail('provider dispatch cannot run inside an outer transaction')
    if (!input || !valid(input.cart_id) || !input.expected || !input.cart) return fail('missing strict expected cart selection')
    const expected = Object.freeze({ ...input.expected })
    if (![expected.session_id, expected.collection_id, expected.intent_id].every(valid) ||
        typeof expected.amount !== 'string' || !/^(?:0|[1-9]\d*)(?:\.\d+)?$/.test(expected.amount) ||
        typeof expected.currency_code !== 'string' || !/^[a-z]{3}$/.test(expected.currency_code)) return fail('invalid expected selection')
    const amount = new BigNumber(expected.amount), minor = getSmallestUnit(amount, expected.currency_code)
    if (!amount.bigNumber?.isFinite() || !Number.isSafeInteger(minor) || minor <= 0 ||
        !MathBN.eq(getAmountFromSmallestUnit(minor, expected.currency_code), amount)) return fail('nonexact provider amount')
    const cartId = input.cart_id
    const cart = Object.freeze({ id: input.cart.id, currency_code: input.cart.currency_code,
      total: MathBN.convert(input.cart.total).toString(), payment_collection: Object.freeze({ id: input.cart.payment_collection?.id }) })
    const readSession = async () => {
      assertWebhookPrepareFence()
      const entity = await service.paymentSessionService_.retrieve(expected.session_id, {
        select: ['id', 'data', 'provider_id', 'amount', 'raw_amount', 'currency_code', 'authorized_at', 'status', 'payment_collection_id'], relations: ['payment']
      }, context)
      assertWebhookPrepareFence()
      const session = { id: entity?.id, provider_id: entity?.provider_id,
        payment_collection_id: entity?.payment_collection_id, currency_code: entity?.currency_code,
        amount: rawAmountString(entity), raw_amount: immutableWebhookJson(entity?.raw_amount),
        authorized_at: entity?.authorized_at, status: entity?.status,
        payment: entity?.payment == null ? null : Object.freeze({ id: entity.payment.id }),
        data: immutableWebhookJson(entity?.data) }
      assertExpectedCartPayment(cart, [session], expected, cartId)
      if (!MathBN.eq(rawAmount(session), amount)) return fail('session amount changed')
      await assertCommerceSessionLock(expected.session_id)
      assertWebhookPrepareFence()
      const bound = await commerceFinancialLockQuery('SELECT 1 AS bound FROM cart_payment_collection WHERE cart_id=? AND payment_collection_id=? AND deleted_at IS NULL', [cartId, expected.collection_id], cartId)
      assertWebhookPrepareFence()
      if (!Array.isArray(bound?.rows) || bound.rows.length !== 1 || bound.rows[0]?.bound !== 1) return fail('cart collection binding unavailable')
      await assertCommerceRefundQuarantineClear(expected.collection_id, 'capture')
      assertWebhookPrepareFence()
      return session
    }
    let session = await readSession()
    const existingId = session.payment?.id
    if (session.payment != null && !valid(existingId)) return fail('malformed session payment')
    const readPayment = async (id: string) => {
      assertWebhookPrepareFence()
      const entity = await service.paymentService_.retrieve(id, {
        select: ['id', 'data', 'provider_id', 'payment_collection_id', 'amount', 'raw_amount', 'currency_code', 'captured_at', 'canceled_at'],
        relations: ['captures.raw_amount', 'payment_session']
      }, context)
      assertWebhookPrepareFence()
      const p = Object.freeze({ id: entity?.id, provider_id: entity?.provider_id,
        payment_collection_id: entity?.payment_collection_id, currency_code: entity?.currency_code,
        amount: rawAmountString(entity), raw_amount: immutableWebhookJson(entity?.raw_amount),
        data: immutableWebhookJson(entity?.data), captured_at: entity?.captured_at, canceled_at: entity?.canceled_at,
        payment_session: Object.freeze({ id: entity?.payment_session?.id }),
        captures: Object.freeze(captures(entity).map(row => {
          if (!row || !valid(row.id) || (row.payment_id !== undefined && row.payment_id !== id) ||
              (row.payment != null && row.payment.id !== id)) return fail('capture payment binding changed')
          return Object.freeze({ id: row.id, payment_id: id, amount: rawAmountString(row),
            raw_amount: immutableWebhookJson(row.raw_amount) })
        })) })
      if (p.id !== id || p.payment_session?.id !== expected.session_id) return fail('payment session ownership changed')
      validateWebhookCaptureReservation(p, expected)
      await assertCommercePaymentLock(id, expected.collection_id)
      assertWebhookPrepareFence()
      return p
    }
    let payment = existingId ? await readPayment(existingId) : undefined
    // One native transaction, containing ONLY preparatory payment/capture rows.
    // It commits before authorizePayment (which can already report CAPTURED).
    if (input.recovery_only && (!payment || !input.reservation || payment.id !== input.reservation.payment_id ||
        validateWebhookCaptureReservation(payment, expected)?.id !== input.reservation.capture_id)) return fail('replay reservation unavailable')
    const reserved = input.recovery_only ? Object.freeze({...input.reservation!})
      : await service.reserveMarketplaceWebhookCapture_(session, payment, expected, context, { cart_id: cartId, cart_snapshot: immutableWebhookJson(JSON.parse(JSON.stringify(input.cart))) })
    assertWebhookPrepareFence()
    session = await readSession()
    if (session.payment?.id !== reserved.payment_id) return fail('committed session payment binding changed')
    payment = await readPayment(reserved.payment_id)
    const capture = validateWebhookCaptureReservation(payment, expected)
    if (!capture || capture.id !== reserved.capture_id) return fail('committed capture identity changed')
    let receipt: Record<string, unknown>
    // A reservation from an interrupted new-cart authorization is intentionally
    // retried with the original SESSION id, never canceled/refunded on failure.
    if (!input.recovery_only && !session.authorized_at && input.action === undefined) {
      const authorized = await service.paymentProviderService_.authorizePayment(session.provider_id, {
        data: immutableWebhookJson(session.data), context: { idempotency_key: expected.session_id }
      })
      assertWebhookPrepareFence()
      const providerStatus = authorized.status
      receipt = verifyReceipt(authorized.data, expected, minor, true)
      if ((receipt.status === 'succeeded' && providerStatus !== PaymentSessionStatus.CAPTURED) ||
          (receipt.status === 'requires_capture' && providerStatus !== PaymentSessionStatus.AUTHORIZED)) return fail('authorization status disagrees with receipt')
      // Do not set authorized_at/status or captured_at: final DB-only apply owns
      // ALL final business writes. Stable preparation rows suffice for recovery.
    } else {
      const status = await service.paymentProviderService_.getStatus(payment.provider_id, { data: immutableWebhookJson(payment.data) })
      assertWebhookPrepareFence()
      receipt = verifyReceipt(status.data, expected, minor, true)
    }
    if (payment.captured_at && receipt.status !== 'succeeded') return fail('local captured state disagrees with provider')
    // Revalidate pinned quarantine/session/payment ownership after external awaits.
    session = await readSession()
    if (session.payment?.id !== payment.id) return fail('session rebound after provider read')
    const fresh = await readPayment(payment.id)
    if (validateWebhookCaptureReservation(fresh, expected)?.id !== capture.id) return fail('reservation rebound after provider read')
    if (input.recovery_only && receipt.status !== 'succeeded') return fail('replay requires verified already-succeeded full capture')
    if (receipt.status === 'requires_capture') {
      const result = await service.paymentProviderService_.capturePayment(payment.provider_id, {
        data: receipt, context: { idempotency_key: capture.id }
      })
      assertWebhookPrepareFence()
      receipt = verifyReceipt(result.data, expected, minor, false)
    }
    session = await readSession()
    if (session.payment?.id !== payment.id) return fail('session rebound after dispatch')
    const after = await readPayment(payment.id)
    if (validateWebhookCaptureReservation(after, expected)?.id !== capture.id) return fail('reservation rebound after dispatch')
    assertWebhookPrepareFence()
    const timestamp = Date.now()
    // Date internal slots remain mutable even after Object.freeze. A defensive
    // getter prevents mutation of the prepared state's authoritative timestamp.
    return Object.freeze({ phase: 'PREPARED' as const, payment_id: payment.id, collection_id: expected.collection_id,
      capture_id: capture.id, cart_id: cartId, session_id: expected.session_id, provider_id: payment.provider_id,
      intent_id: expected.intent_id, amount: amount.bigNumber.toString(), minor_amount: minor,
      currency_code: expected.currency_code, receipt, allocations: Object.freeze([]),
      get captured_at() { return new Date(timestamp) } })
  } catch (error) { revokeCommerceFinancialWork(); throw error }
}
