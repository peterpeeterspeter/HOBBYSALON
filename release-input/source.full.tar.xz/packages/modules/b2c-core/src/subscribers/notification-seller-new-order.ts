import { SubscriberArgs, SubscriberConfig } from "@medusajs/framework";
import {
  ContainerRegistrationKeys,
  Modules,
  OrderWorkflowEvents,
} from "@medusajs/framework/utils";

import type { OrderNotificationOutcomeService } from '../types/order-notification-outcome';

export default async function sellerNewOrderHandler({
  event,
  container,
}: SubscriberArgs<{ order_ids: string[] }>) {
  const orderIds = event?.data?.order_ids;
  if (
    !Array.isArray(orderIds) || !orderIds.length ||
    orderIds.some((id) => typeof id !== "string" || !id.trim()) ||
    new Set(orderIds).size !== orderIds.length
  ) {
    throw new Error("Invalid seller notification order IDs");
  }
  const notificationService = container.resolve<OrderNotificationOutcomeService>(Modules.NOTIFICATION);
  const query = container.resolve(ContainerRegistrationKeys.QUERY);
  const errors: unknown[] = [];

  for (const orderId of orderIds) {
    try {
      const result = await query.graph({
        entity: "order",
        fields: [
          "id",
          "display_id",
          "items.*",
          "seller.email",
          "seller.name",
          "seller.id",
          "customer.first_name",
          "customer.last_name",
        ],
        filters: {
          id: orderId,
        },
      });

      if (!Array.isArray(result?.data) || result.data.length !== 1) {
        throw new Error("Seller notification requires exactly one order");
      }
      const order = result.data[0];
      if (!order || order.id !== orderId) {
        throw new Error("Seller notification order identity mismatch");
      }

      const sellerEmail = order.seller?.email;
      if (typeof sellerEmail !== "string" || !sellerEmail.trim()) {
        throw new Error("Seller notification requires seller email");
      }
      const sellerId = order.seller?.id;
      if (typeof sellerId !== "string" || !sellerId.trim()) {
        throw new Error("Seller notification requires seller ID");
      }

      const customer_name = `${order.customer?.first_name || ""} ${order.customer?.last_name || ""}`;
      await notificationService.createOrderNotifications([
        {
          to: sellerId,
          channel: "seller_feed",
          template: "seller_new_order_notification",
          // Stable on retry; historical unkeyed feeds are not retroactively deduped.
          idempotency_key: `seller-new-order-feed:${order.id}`,
          data: {
            order_id: order.id,
            customer_name,
          },
        },
      ]);
    } catch (error) {
      console.error("Error processing seller order notification:", error);
      errors.push(error);
    }
  }
  if (errors.length) {
    throw new AggregateError(errors, "Seller order notifications failed");
  }
}

export const config: SubscriberConfig = {
  event: OrderWorkflowEvents.PLACED,
  context: {
    subscriberId: "seller-new-order-handler",
  },
};
