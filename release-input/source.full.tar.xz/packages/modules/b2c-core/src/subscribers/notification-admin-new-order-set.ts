import { ContainerRegistrationKeys, Modules } from '@medusajs/framework/utils'
import { SubscriberArgs, SubscriberConfig } from '@medusajs/medusa'

import { OrderSetWorkflowEvents } from '@mercurjs/framework'
import type { OrderNotificationOutcomeService } from '../types/order-notification-outcome'

export default async function newOrderSetAdminNotifyHandler({
  event,
  container
}: SubscriberArgs<{ id: string }>) {
  const orderSetId = event?.data?.id
  if (typeof orderSetId !== 'string' || !orderSetId.trim()) {
    throw new Error('Admin notification requires order set ID')
  }
  const notificationService = container.resolve<OrderNotificationOutcomeService>(Modules.NOTIFICATION)
  const query = container.resolve(ContainerRegistrationKeys.QUERY)

  const result = await query.graph({
    entity: 'order_set',
    fields: ['id', 'orders.id'],
    filters: {
      id: orderSetId
    }
  })

  if (!Array.isArray(result?.data) || result.data.length !== 1) {
    throw new Error('Admin notification requires exactly one order set')
  }
  const order_set = result.data[0]
  if (!order_set || order_set.id !== orderSetId || !Array.isArray(order_set.orders) ||
      order_set.orders.some((order) => typeof order?.id !== 'string' || !order.id.trim()) ||
      new Set(order_set.orders.map((order) => order.id)).size !== order_set.orders.length) {
    throw new Error('Admin notification requires complete valid orders relation')
  }
  if (order_set.orders.length < 2) {
    return
  }

  await notificationService.createOrderNotifications({
    to: '',
    channel: 'feed',
    template: 'admin-ui',
    // Stable on retry; historical unkeyed feeds are not retroactively deduped.
    idempotency_key: `admin-new-order-set-feed:${orderSetId}`,
    content: {
      subject: `New Order Set Placed`
    },
    data: {
      title: `New order set placed`,
      description: 'Someone has placed a new order from multiple sellers 🔔',
      redirect: '/admin/orders'
    }
  })
}

export const config: SubscriberConfig = {
  event: OrderSetWorkflowEvents.PLACED,
  context: {
    subscriberId: 'new-order-set-admin-notify-handler'
  }
}
