import type {
  Context,
  CreateNotificationDTO,
  INotificationModuleService,
  NotificationDTO,
} from '@medusajs/types'

/**
 * Local DI requirement of these order subscribers. Not a global native-interface
 * augmentation: an arbitrary native notification service need not provide it.
 * Empty native retry/skip returns remain possible after checked row readback.
 * This is not an external-delivery or consumer-ACK receipt.
 */
export interface OrderNotificationOutcomeService extends INotificationModuleService {
  createOrderNotifications(
    data: CreateNotificationDTO | CreateNotificationDTO[],
    sharedContext?: Context,
  ): Promise<NotificationDTO | NotificationDTO[] | undefined>
}
