import { createHash } from 'node:crypto'
import { parse as parsePgConnectionString } from 'pg-connection-string'
import { ContainerRegistrationKeys, MathBN, PaymentActions } from '@medusajs/framework/utils'
import { assertCommerceCartLock, commerceCartLockQuery, withCommerceCartLock } from './commerce-cart-lock'
import { assertCompletedCartOrderSet, completedCartFields, completedOrderSetFields } from './completed-cart-order-set'
import { assertCommerceRefundQuarantineClear } from './commerce-refund-quarantine'

/** Private candidate: this is the actual placed FINANCIAL subscriber, after the
 * parent's DB-only finalization. It validates already committed native finances
 * and records ONLY its own durable member ACK. No capture, repair, workflow,
 * provider, notification or broker call. Other placed/native mutation recipients
 * are NOT covered; neither full delivery nor tail completion is claimed here. */
const subscriberId = 'order-set-placed-payment-capture'
const outboxKey = 'marketplace_webhook_outbox_id', eventKey = 'marketplace_webhook_event_id'
const fail = (): never => { throw new Error('Atomic marketplace financial consumer binding unavailable or changed; reconciliation required') }
const plain = (v: any): boolean => !!v && typeof v === 'object' && !Array.isArray(v) &&
  (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null)
function id(v: any): string {
  if (typeof v !== 'string' || !v || v.length > 255 || v.trim() !== v || /[\u0000-\u001f\u007f]/.test(v)) fail()
  return v
}
function amount(v: any): string {
  try {
    if (v == null) return fail()
    const n = MathBN.convert(v)
    if (!n.isFinite() || MathBN.lt(n, 0)) return fail()
    return n.toString()
  } catch { return fail() }
}
function sameAmount(a: any, b: any): boolean { return amount(a) === amount(b) }
function stamp(v: any): boolean {
  return (typeof v === 'string' || v instanceof Date) && Number.isFinite(new Date(v).getTime())
}
function stable(v: any): string {
  return JSON.stringify(v, (_k, x) => x && typeof x === 'object' && !Array.isArray(x)
    ? Object.fromEntries(Object.keys(x).sort().map(k => [k, x[k]])) : x)
}
const owns = (v: any, key: string): boolean => Object.prototype.hasOwnProperty.call(v,key)
const hash = (s: string): string => createHash('sha256').update(s).digest('hex')
async function graph(container: any, entity: string, fields: string[], filters: any): Promise<any[]> {
  const result = await container.resolve(ContainerRegistrationKeys.QUERY).graph({entity,fields,filters})
  if (!Array.isArray(result?.data)) fail()
  return result.data
}
/** Same locked, read-only guard for ordinary untagged events. Transport tags may
 * be missing from a native emission. They are NEVER permission to fall back to
 * legacy capture when a reservation carries the atomic protocol. Unknown stored
 * protocols/malformed tails also fail closed; absent tails remain legacy. */
export async function assertNoAtomicMarketplaceCaptureUnderLock(container: any, cartId: string, collectionId: string): Promise<void> {
  const check = () => assertCommerceCartLock(container,cartId)
  check()
  const payments = await graph(container,'payment',['id','payment_collection_id'],{payment_collection_id:collectionId}); check()
  if (payments.length !== 1 || payments[0].payment_collection_id !== collectionId) fail()
  const paymentId = id(payments[0].id)
  const result = await commerceCartLockQuery(container,cartId,'SELECT * FROM marketplace_capture_tail WHERE payment_id = ?',[paymentId]); check()
  if (!Array.isArray(result?.rows) || result.rows.length > 1) fail()
  if (!result.rows.length) return
  const tail = result.rows[0]
  if (tail.payment_id !== paymentId || tail.cart_id !== cartId || !plain(tail.snapshot) ||
      tail.snapshot.protocol !== undefined) fail()
}
const committedSql = `SELECT o.id,o.event_id,o.event_name,o.payload,
  to_jsonb(r) AS receipt,to_jsonb(m) AS manifest
  FROM marketplace_webhook_outbox o
  JOIN marketplace_stripe_event_receipt r ON r.event_id=o.event_id
  JOIN marketplace_webhook_commit m ON m.event_id=r.event_id
  WHERE o.id=? AND o.event_id=?`
function message(v: any, persisted: boolean): any {
  if (!plain(v) || v.name !== 'order_set.placed' || !plain(v.data) ||
      (v.metadata !== undefined && !plain(v.metadata))) fail()
  const metadata = {...(v.metadata ?? {})}
  // These TWO transport binding keys alone are authorized additions. Unknown
  // correlation fields, event groups and completed-subscriber bypasses are not
  // silently stripped. options is broker scheduling, not subscriber payload.
  if (metadata.eventGroupId != null || metadata.completedSubscriberIds != null) fail()
  if (persisted && (owns(metadata,outboxKey) || owns(metadata,eventKey))) fail()
  delete metadata[outboxKey]; delete metadata[eventKey]
  return {name:v.name,data:v.data,metadata}
}
function bound(row: any, event: any, outboxId: string, eventId: string): any {
  if (!plain(row) || row.id !== outboxId || row.event_id !== eventId || row.event_name !== 'order_set.placed' ||
      !plain(row.receipt) || !plain(row.manifest) || stable(message(row.payload,true)) !== stable(message(event,false))) fail()
  const m = row.manifest, r = row.receipt
  if (m.event_id !== eventId || r.event_id !== eventId || !stamp(m.created_at) ||
      id(m.cart_id) !== r.cart_id || id(m.order_set_id) !== id(row.payload.data.id) ||
      id(event.data.id) !== m.order_set_id || !id(m.payment_id) || !id(m.capture_id) ||
      !Array.isArray(m.outbox_ids) || !m.outbox_ids.length || new Set(m.outbox_ids).size !== m.outbox_ids.length ||
      m.outbox_ids.some((v: any) => typeof v !== 'string' || !/^[a-f0-9]{64}$/.test(v)) || !m.outbox_ids.includes(outboxId) ||
      !Array.isArray(m.allocations) || !m.allocations.length ||
      new Set(m.allocations.map((a: any) => a?.order_id)).size !== m.allocations.length ||
      new Set(m.allocations.map((a: any) => a?.split_id)).size !== m.allocations.length) fail()
  for (const a of m.allocations) {
    if (!plain(a) || !id(a.order_id) || !id(a.split_id) || typeof a.amount !== 'string' ||
        !/^[a-z]{3}$/.test(a.currency_code) || !MathBN.gt(amount(a.amount),0)) fail()
  }
  return m
}
/** Normalize only the validation view; never rewrite the reservation. Keep item
 * prices, quantities, taxes, adjustments, shipping and customer/address binding.
 * Completion timestamps/payment collections are mutable finalization results. */
function cartShape(c: any): any {
  const scalar = (v: any) => v?.toNumber ? v.toNumber() : v
  const fields = (v: any, names: string[]) => Object.fromEntries(names.map(k => [k,scalar(v?.[k]) ?? null]))
  const adjustment = (a: any) => fields(a,['id','amount','code','promotion_id','description'])
  const tax = (a: any) => fields(a,['id','rate','code','tax_rate_id','provider_id'])
  const rows = (values: any[], keys: string[]) => (values ?? []).map(v => ({...fields(v,keys),
    adjustments:(v.adjustments ?? []).map(adjustment).sort((a: any,b: any) => stable(a).localeCompare(stable(b))),
    tax_lines:(v.tax_lines ?? []).map(tax).sort((a: any,b: any) => stable(a).localeCompare(stable(b)))
  })).sort((a: any,b: any) => id(a.id).localeCompare(id(b.id)))
  return {...fields({...c,region_id:c.region_id ?? c.region?.id,customer_id:c.customer_id ?? c.customer?.id},['id','currency_code','email','customer_id','sales_channel_id','region_id','total']),
    items:rows(c.items,['id','variant_id','product_id','quantity','unit_price','compare_at_unit_price','is_tax_inclusive','requires_shipping','metadata']),
    shipping_methods:rows(c.shipping_methods,['id','shipping_option_id','name','description','amount','is_tax_inclusive','data','metadata']),
    shipping_address:fields(c.shipping_address,['id','first_name','last_name','address_1','address_2','city','country_code','postal_code','province','phone','company']),
    billing_address:fields(c.billing_address,['id','first_name','last_name','address_1','address_2','city','country_code','postal_code','province','phone','company'])}
}
function nativeManager(container: any): any {
  const root = container.resolve('payment')?.baseRepository_?.manager_
  if (!root || typeof root.fork !== 'function' || typeof root.execute !== 'function' ||
      typeof root.transactional !== 'function' || typeof root.getTransactionContext !== 'function' || root.getTransactionContext()) fail()
  // The advisory-lock session and native ACK transaction must target the same
  // database. Different clients are expected; matching an ALS cart alone is not
  // permission for a cross-database ACK. Unknown configuration fails closed.
  const pg = container.resolve(ContainerRegistrationKeys.PG_CONNECTION)
  const nativeKnex = root.getConnection?.().getKnex?.()
  if (!pg?.client || pg.isTransaction || pg.client.transacting || !nativeKnex?.client) fail()
  const config = (knex: any) => {
    const c = knex.client.config?.connection
    if (!plain(c)) return fail()
    let effective: any = c
    if (c.connectionString !== undefined) {
      if (typeof c.connectionString !== 'string' || !/^postgres(?:ql)?:\/\//.test(c.connectionString)) fail()
      try { effective = {...c,...parsePgConnectionString(c.connectionString)} } catch { return fail() }
    }
    // Match retained node-postgres precedence: connectionString overrides fields.
    // Refuse ambient user/database defaults rather than silently consulting PG*.
    const {database,user,host} = effective
    // Only canonical decimal input: Number('5.432e3') and native parseInt
    // disagree. Refuse noncanonical ports even on a shared client.
    const explicitPort = effective.port !== undefined && effective.port !== null && effective.port !== ''
    if (explicitPort && !['string','number'].includes(typeof effective.port)) return fail()
    if (explicitPort && !/^[1-9][0-9]{0,4}$/.test(String(effective.port))) return fail()
    const port = explicitPort ? Number(effective.port) : null
    if (explicitPort && (!Number.isSafeInteger(port) || port! < 1 || port! > 65535)) return fail()
    if (typeof database !== 'string' || !database || typeof user !== 'string' || !user ||
        (pg !== nativeKnex && (typeof host !== 'string' || !host || !explicitPort)) ||
        effective.options || process.env.PGOPTIONS) return fail()
    const search = knex.client.config.searchPath
    // Raw SQL is intentionally public-only. Missing/default/server paths and
    // comma-containing strings are NOT equivalent to a verified explicit path.
    const schema = typeof search === 'string' ? [search] : search
    if (!Array.isArray(schema) || schema.length !== 1 || schema[0] !== 'public') return fail()
    return stable([host ?? null,effective.port ? port : null,database,user,schema])
  }
  if (config(pg) !== config(nativeKnex)) fail()
  const fork = root.fork({clear:true,useContext:false,disableContextResolution:true})
  if (fork.getTransactionContext()) fail()
  return fork
}
async function validateFinances(container: any, row: any, m: any, check: () => void): Promise<void> {
  check()
  // The retained tail schema has NO captured_at column. Read the committed
  // native payment timestamp explicitly, rather than inventing a tail field.
  const tails = await commerceCartLockQuery(container,m.cart_id,`SELECT t.*,p.captured_at AS native_captured_at
    FROM marketplace_capture_tail t JOIN payment p ON p.id=t.payment_id
    WHERE t.payment_id=? AND p.deleted_at IS NULL`,[m.payment_id]); check()
  if (!Array.isArray(tails?.rows) || tails.rows.length !== 1) fail()
  const tail = tails.rows[0], s = tail.snapshot, r = row.receipt
  if (tail.payment_id !== m.payment_id || tail.cart_id !== m.cart_id || tail.capture_id !== m.capture_id ||
      !stamp(tail.native_captured_at) || !stamp(tail.accounting_at) || !plain(s) || s.version !== 1 ||
      s.protocol !== 'atomic-stripe-event' || s.payment_id !== m.payment_id || s.cart_id !== m.cart_id ||
      !plain(s.cart_snapshot) || !Array.isArray(s.allocations) || s.allocations.length ||
      s.provider_id !== 'pp_card_stripe-connect' || typeof s.amount !== 'string' || !MathBN.gt(amount(s.amount),0) ||
      !/^[a-z]{3}$/.test(s.currency_code) || !id(s.session_id) || !id(s.collection_id) || !id(s.intent_id) ||
      tail.event_id !== `marketplace-captured-${hash(stable(s))}` ||
      r.payment_collection_id !== s.collection_id || r.payment_intent_id !== s.intent_id ||
      ![PaymentActions.AUTHORIZED,PaymentActions.SUCCESSFUL].includes(r.action) ||
      r.fingerprint !== hash(JSON.stringify([r.event_id,s.provider_id,r.action,s.cart_id,s.session_id,s.collection_id,s.intent_id,s.amount,s.currency_code]))) fail()
  await assertCommerceRefundQuarantineClear(s.collection_id); check()
  const expected = {session_id:s.session_id,collection_id:s.collection_id,intent_id:s.intent_id,amount:s.amount,currency_code:s.currency_code}
  const carts = await graph(container,'cart',completedCartFields,{id:m.cart_id}); check()
  const sets = await graph(container,'order_set',[...completedOrderSetFields,'orders.version','orders.status',
    'orders.split_order_payment.status','orders.split_order_payment.captured_amount','orders.split_order_payment.refunded_amount'],{cart_id:m.cart_id}); check()
  if (carts.length !== 1 || !stamp(carts[0].completed_at) || stable(cartShape(carts[0])) !== stable(cartShape(s.cart_snapshot))) fail()
  assertCompletedCartOrderSet(carts[0],sets,m.cart_id,expected)
  if (sets[0].id !== m.order_set_id || sets[0].orders.length !== m.allocations.length) fail()
  const paymentService = container.resolve('payment')
  const payment = await paymentService.retrievePayment(m.payment_id,{relations:['captures','refunds']}); check()
  const matches = (v: any) => v && !v.deleted_at && v.payment_collection_id === s.collection_id &&
    v.provider_id === s.provider_id && v.currency_code === s.currency_code && sameAmount(v.amount,s.amount) &&
    v.data?.id === s.intent_id && v.data?.status === 'succeeded'
  if (!matches(payment) || payment.id !== m.payment_id || payment.payment_session_id !== s.session_id ||
      !stamp(payment.captured_at) || payment.canceled_at || !Array.isArray(payment.refunds) || payment.refunds.length ||
      !Array.isArray(payment.captures) || payment.captures.length !== 1 ||
      payment.captures[0]?.id !== m.capture_id || payment.captures[0].payment_id !== m.payment_id ||
      payment.captures[0].deleted_at || !sameAmount(payment.captures[0].amount,s.amount)) fail()
  const collection = await paymentService.retrievePaymentCollection(s.collection_id,{relations:['payment_sessions','payments']}); check()
  if (!collection || collection.deleted_at || collection.id !== s.collection_id || collection.currency_code !== s.currency_code ||
      !sameAmount(collection.amount,s.amount) || !sameAmount(collection.authorized_amount,s.amount) ||
      !sameAmount(collection.captured_amount,s.amount) || amount(collection.refunded_amount) !== '0' ||
      collection.status !== 'completed' || !stamp(collection.completed_at) ||
      !Array.isArray(collection.payment_sessions) || collection.payment_sessions.length !== 1 ||
      collection.payment_sessions[0]?.id !== s.session_id || !Array.isArray(collection.payments) ||
      collection.payments.length !== 1 || collection.payments[0]?.id !== m.payment_id) fail()
  const session = await paymentService.retrievePaymentSession(s.session_id); check()
  if (!matches(session) || session.id !== s.session_id || session.status !== 'captured' || !stamp(session.authorized_at) ||
      !matches(collection.payment_sessions[0]) || collection.payment_sessions[0].status !== 'captured' ||
      !matches(collection.payments[0]) || !stamp(collection.payments[0].captured_at)) fail()
  const orderService = container.resolve('order'), splitService = container.resolve('split_order_payment')
  let total = MathBN.convert(0)
  for (const allocation of m.allocations) {
    const orders = sets[0].orders.filter((o: any) => o.id === allocation.order_id)
    if (orders.length !== 1) fail()
    const o = orders[0], summary = o.summary
    if (o.deleted_at || !['pending','completed'].includes(o.status) || !Number.isSafeInteger(o.version) || o.version < 1 ||
        o.currency_code !== s.currency_code || allocation.currency_code !== s.currency_code ||
        o.split_order_payment.id !== allocation.split_id || !summary ||
        !sameAmount(summary.accounting_total,allocation.amount) || !sameAmount(summary.paid_total,allocation.amount) ||
        !sameAmount(summary.transaction_total,allocation.amount) || amount(summary.refunded_total) !== '0' ||
        amount(summary.credit_line_total) !== '0' || amount(summary.pending_difference) !== '0') fail()
    const splits = await splitService.listSplitOrderPayments({id:allocation.split_id},{take:2,withDeleted:true}); check()
    const splitMatches = (split: any) => split && !split.deleted_at && split.id === allocation.split_id &&
      split.payment_collection_id === s.collection_id && split.currency_code === s.currency_code && split.status === 'captured' &&
      sameAmount(split.authorized_amount,allocation.amount) && sameAmount(split.captured_amount,allocation.amount) && amount(split.refunded_amount) === '0'
    if (!Array.isArray(splits) || splits.length !== 1 || !splitMatches(splits[0]) || !splitMatches(o.split_order_payment)) fail()
    // Read ALL transactions, not a capture-only filter hiding unexpected refunds
    // or extra captures. Tombstones are accounting evidence, never ignored.
    const transactions = await orderService.listOrderTransactions({order_id:o.id},{take:2,withDeleted:true}); check()
    if (!Array.isArray(transactions) || transactions.length !== 1) fail()
    const t = transactions[0]
    if (!t || !id(t.id) || t.deleted_at || t.order_id !== o.id || t.version !== o.version ||
        t.reference !== 'capture' || t.reference_id !== m.capture_id || t.currency_code !== s.currency_code ||
        !sameAmount(t.amount,allocation.amount)) fail()
    total = MathBN.add(total,amount(allocation.amount))
  }
  if (!sameAmount(total,s.amount)) fail()
  check()
}

/** Both transport tags are mandatory. Caller metadata is only routing; the
 * locked outbox + committed receipt + immutable parent manifest are authority.
 * The root read completes before advisory lock acquisition; it grants no ACK. */
export async function consumeAtomicMarketplaceOrderSetPlaced(container: any, input: any): Promise<void> {
  const event = JSON.parse(JSON.stringify(input))
  if (!plain(event?.metadata) || !owns(event.metadata,outboxKey) || !owns(event.metadata,eventKey)) fail()
  const outboxId = id(event.metadata[outboxKey]), eventId = id(event.metadata[eventKey])
  if (!/^[a-f0-9]{64}$/.test(outboxId)) fail()
  const manager = nativeManager(container)
  const hints = await manager.execute(committedSql,[outboxId,eventId])
  if (!Array.isArray(hints) || hints.length !== 1) fail()
  const hint = hints[0], selected = bound(hint,event,outboxId,eventId)
  await withCommerceCartLock(container,selected.cart_id,async () => {
    const cartId = selected.cart_id
    assertCommerceCartLock(container,cartId)
    await manager.transactional(async (owner: any) => {
      const trx = owner.getTransactionContext()
      const check = () => {
        assertCommerceCartLock(container,cartId)
        if (!trx?.isTransaction || trx.isCompleted() || owner.getTransactionContext() !== trx) fail()
      }
      const execute = async (sql: string, values: any[] = []) => {
        check(); const rows = await owner.execute(sql,values); check()
        if (!Array.isArray(rows)) fail()
        return rows
      }
      await execute('SET LOCAL synchronous_commit = on')
      const rows = await execute(`${committedSql} FOR UPDATE OF o`,[outboxId,eventId])
      if (rows.length !== 1 || stable(rows[0]) !== stable(hint)) fail()
      const row = rows[0], manifest = bound(row,event,outboxId,eventId)
      if (manifest.cart_id !== cartId) fail()
      await validateFinances(container,row,manifest,check); check()
      const inserted = await execute(`INSERT INTO marketplace_webhook_consumer_ack (outbox_id,subscriber_id,event_id)
        VALUES (?,?,?) ON CONFLICT (outbox_id,subscriber_id) DO NOTHING RETURNING outbox_id,subscriber_id,event_id,acked_at`,
        [outboxId,subscriberId,eventId])
      if (inserted.length > 1) fail()
      const acks = await execute('SELECT * FROM marketplace_webhook_consumer_ack WHERE outbox_id=? AND subscriber_id=?',[outboxId,subscriberId])
      const validAck = (a: any) => a && a.outbox_id === outboxId && a.subscriber_id === subscriberId && a.event_id === eventId && stamp(a.acked_at)
      if (acks.length !== 1 || !validAck(acks[0]) || (inserted.length === 1 && (!validAck(inserted[0]) || stable(inserted[0]) !== stable(acks[0])))) fail()
      // No delivered_at / completed_at update: one financial member is not a
      // complete manifest of the six placed handlers/native mutation consumers.
      check()
    },{clear:true})
    assertCommerceCartLock(container,cartId)
  })
}
