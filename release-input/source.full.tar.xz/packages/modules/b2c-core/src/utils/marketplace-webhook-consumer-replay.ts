import { ContainerRegistrationKeys } from '@medusajs/framework/utils'
import { consumeAtomicMarketplaceOrderSetPlaced } from './marketplace-webhook-consumer-ack'

const member = 'order-set-placed-payment-capture'
const outboxKey = 'marketplace_webhook_outbox_id', eventKey = 'marketplace_webhook_event_id'
const fail = (): never => { throw new Error('Financial member ACK replay requires reconciliation') }
const plain = (v: any): boolean => !!v && typeof v === 'object' && !Array.isArray(v) &&
  (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null)
const owns = (v: any, key: string): boolean => Object.prototype.hasOwnProperty.call(v,key)
function identity(v: any): string {
  if (typeof v !== 'string' || !v || v.length > 255 || v.trim() !== v || /[\u0000-\u001f\u007f]/.test(v)) fail()
  return v
}
/** Separate autocommitted operational cursor, never financial authority. The
 * actual consumer reauthenticates payload/receipt/manifest and committed native
 * finances under its own locks before inserting ONLY its member ACK. No broker,
 * provider, completion, delivered marker or tail mutation belongs to this path. */
export async function replayMarketplaceWebhookFinancialAck(container: any, outboxId: string, eventId: string): Promise<void> {
  identity(outboxId); identity(eventId)
  if (!/^[a-f0-9]{64}$/.test(outboxId)) fail()
  const pg = container.resolve(ContainerRegistrationKeys.PG_CONNECTION)
  // Refuse a caller-owned transaction: the cursor must survive consumer rollback.
  if (!pg?.raw || !pg.client || pg.isTransaction || pg.client.transacting) fail()
  await pg.raw(`INSERT INTO marketplace_webhook_consumer_attempt (outbox_id)
    VALUES (?) ON CONFLICT (outbox_id) DO NOTHING`,[outboxId])
  const claimed = await pg.raw(`WITH candidate AS (
    SELECT a.outbox_id FROM marketplace_webhook_consumer_attempt a
    INNER JOIN marketplace_webhook_outbox o ON o.id=a.outbox_id
    INNER JOIN marketplace_stripe_event_receipt r ON r.event_id=o.event_id
    INNER JOIN marketplace_webhook_commit m ON m.event_id=r.event_id
    WHERE o.id=? AND o.event_id=? AND o.event_name='order_set.placed'
    AND a.available_at<=now()
    AND NOT EXISTS (SELECT 1 FROM marketplace_webhook_consumer_ack k
      WHERE k.outbox_id=o.id AND k.subscriber_id=?)
    FOR UPDATE OF a SKIP LOCKED
  ) UPDATE marketplace_webhook_consumer_attempt a
    SET available_at=now()+interval '5 minutes', attempts=a.attempts+1, last_error=NULL
    FROM candidate c, marketplace_webhook_outbox o
    WHERE a.outbox_id=c.outbox_id AND o.id=a.outbox_id
    AND o.event_id=? AND o.event_name='order_set.placed' AND a.available_at<=now()
    AND NOT EXISTS (SELECT 1 FROM marketplace_webhook_consumer_ack k
      WHERE k.outbox_id=o.id AND k.subscriber_id=?)
    RETURNING a.outbox_id,a.attempts,a.available_at,o.event_id,o.payload`,
  [outboxId,eventId,member,eventId,member])
  if (!Array.isArray(claimed?.rows) || claimed.rows.length > 1) fail()
  if (!claimed.rows.length) return
  const row = claimed.rows[0]
  if (row.outbox_id !== outboxId || row.event_id !== eventId || !Number.isSafeInteger(row.attempts) || row.attempts < 1) fail()
  try {
    // Validate before cloning/pinning: do not silently strip persisted bypasses.
    const saved = row.payload
    if (!plain(saved) || saved.name !== 'order_set.placed' || !plain(saved.data) ||
        (saved.metadata !== undefined && !plain(saved.metadata))) fail()
    const metadata = saved.metadata ?? {}
    for (const key of [outboxKey,eventKey,'eventGroupId','completedSubscriberIds']) if (owns(metadata,key)) fail()
    // Broker scheduling options are not consumer input or ACK authority.
    const event = JSON.parse(JSON.stringify({name:saved.name,data:saved.data,metadata}))
    event.metadata[outboxKey] = outboxId
    event.metadata[eventKey] = eventId
    await consumeAtomicMarketplaceOrderSetPlaced(container,event)
    // Success is exclusively the real consumer's immutable member ACK.
  } catch {
    await pg.raw(`UPDATE marketplace_webhook_consumer_attempt SET last_error=?
      WHERE outbox_id=? AND attempts=?`,
    ['Financial member ACK reconciliation required; no automatic financial retry',outboxId,row.attempts])
    fail()
  }
}
