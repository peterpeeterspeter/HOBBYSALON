import type { MedusaContainer } from '@medusajs/framework/types'
import { ContainerRegistrationKeys } from '@medusajs/framework/utils'
import { replayMarketplaceWebhookFinancialAck } from '../utils/marketplace-webhook-consumer-replay'

/** Default-off recovery of one FINANCIAL member ACK, including lost/exhausted
 * broker jobs. No re-emission to the other placed handlers; delivery status and
 * broker retry counters intentionally play no role in eligibility. */
export default async function marketplaceWebhookConsumerReplayJob(container: MedusaContainer) {
  if (process.env.COMMERCE_WEBHOOK_FINANCIAL_ACK_REPLAY_ENABLED !== 'true') return
  const pg = container.resolve(ContainerRegistrationKeys.PG_CONNECTION)
  if (!pg?.raw || !pg.client || pg.isTransaction || pg.client.transacting) throw new Error('Financial ACK replay storage unavailable')
  const { rows } = await pg.raw(`SELECT o.id,o.event_id FROM marketplace_webhook_outbox o
    INNER JOIN marketplace_stripe_event_receipt r ON r.event_id=o.event_id
    INNER JOIN marketplace_webhook_commit m ON m.event_id=r.event_id
    LEFT JOIN marketplace_webhook_consumer_attempt a ON a.outbox_id=o.id
    WHERE o.event_name='order_set.placed'
    AND NOT EXISTS (SELECT 1 FROM marketplace_webhook_consumer_ack k
      WHERE k.outbox_id=o.id AND k.subscriber_id=?)
    AND (a.outbox_id IS NULL OR a.available_at<=now())
    ORDER BY a.available_at NULLS FIRST, o.created_at, o.id LIMIT 20`,['order-set-placed-payment-capture'])
  if (!Array.isArray(rows)) throw new Error('Financial ACK replay selection unavailable')
  for (const row of rows.slice(0,20)) {
    try { await replayMarketplaceWebhookFinancialAck(container,row.id,row.event_id) }
    catch { container.resolve(ContainerRegistrationKeys.LOGGER).warn('Financial member ACK replay deferred; reconciliation required') }
  }
}
export const config = { name: 'marketplace-webhook-consumer-replay', schedule: '*/5 * * * *' }
