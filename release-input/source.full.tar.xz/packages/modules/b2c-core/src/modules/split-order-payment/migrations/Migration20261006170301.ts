import { Migration } from '@medusajs/framework/mikro-orm/migrations'

/** Transactional delivery intent, not a Redis job or proof of delivery. */
export class Migration20261006170301 extends Migration {
  override async up(): Promise<void> {
    this.addSql(`CREATE TABLE marketplace_webhook_outbox (
      id text PRIMARY KEY CHECK (id ~ '^[0-9a-f]{64}$'),
      event_id text NOT NULL REFERENCES marketplace_stripe_event_receipt(event_id),
      event_name text NOT NULL CHECK (length(event_name)>0),
      payload jsonb NOT NULL,
      created_at timestamptz NOT NULL DEFAULT now(),
      available_at timestamptz NOT NULL DEFAULT now(),
      delivered_at timestamptz,
      attempts integer NOT NULL DEFAULT 0 CHECK (attempts>=0),
      last_error text
    );
    CREATE INDEX marketplace_webhook_outbox_pending_idx
      ON marketplace_webhook_outbox (available_at,created_at,id) WHERE delivered_at IS NULL;
    REVOKE ALL ON marketplace_webhook_outbox FROM PUBLIC;`)
  }
  override async down(): Promise<void> {
    throw new Error('Webhook outbox delivery intent is durable; destructive rollback forbidden')
  }
}
