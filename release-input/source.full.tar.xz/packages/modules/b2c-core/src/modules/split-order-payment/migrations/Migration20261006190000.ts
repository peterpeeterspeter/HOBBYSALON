import { Migration } from '@medusajs/framework/mikro-orm/migrations'

/** Broker acceptance is not business delivery. No consumer ACK is synthesized. */
export class Migration20261006190000 extends Migration {
  override async up(): Promise<void> {
    this.addSql(`ALTER TABLE marketplace_webhook_outbox ADD COLUMN enqueued_at timestamptz;
      CREATE INDEX marketplace_webhook_outbox_transport_pending_idx
        ON marketplace_webhook_outbox (available_at,created_at,id)
        WHERE enqueued_at IS NULL AND delivered_at IS NULL;`)
  }
  override async down(): Promise<void> {
    throw new Error('Webhook transport evidence is durable; destructive rollback forbidden')
  }
}
