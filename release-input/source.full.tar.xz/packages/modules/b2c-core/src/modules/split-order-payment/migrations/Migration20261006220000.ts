import { Migration } from '@medusajs/framework/mikro-orm/migrations'

/** Private additive protocol rows in the migration's configured commerce schema/database.
 * DDL is retained only; never executed here. Member ACK is not all-recipient delivery.
 * Historical reservations are not rewritten. Attempts are mutable, accepted identities are not. */
export class Migration20261006220000 extends Migration {
  override async up(): Promise<void> {
    this.addSql(`CREATE TABLE marketplace_webhook_admission (
      event_id text PRIMARY KEY CHECK (length(event_id) BETWEEN 1 AND 255),
      fingerprint text NOT NULL CHECK (fingerprint ~ '^[0-9a-f]{64}$'),
      cart_id text NOT NULL, session_id text NOT NULL,
      input jsonb NOT NULL CHECK (jsonb_typeof(input)='object'),
      created_at timestamptz NOT NULL DEFAULT now(),
      UNIQUE (event_id,cart_id),
      CONSTRAINT marketplace_webhook_admission_input_identity CHECK (
        jsonb_typeof(input->'event_id') IS NOT DISTINCT FROM 'string' AND
        jsonb_typeof(input->'data') IS NOT DISTINCT FROM 'object' AND
        jsonb_typeof(input->'data'->'cart_id') IS NOT DISTINCT FROM 'string' AND
        jsonb_typeof(input->'data'->'session_id') IS NOT DISTINCT FROM 'string' AND
        (input->>'event_id') IS NOT DISTINCT FROM event_id AND
        (input->'data'->>'cart_id') IS NOT DISTINCT FROM cart_id AND
        (input->'data'->>'session_id') IS NOT DISTINCT FROM session_id
      )
    );
    CREATE TABLE marketplace_webhook_replay_attempt (
      event_id text PRIMARY KEY REFERENCES marketplace_webhook_admission(event_id) ON DELETE RESTRICT,
      last_attempt_at timestamptz,
      attempts integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
      last_error text
    );
    CREATE TABLE marketplace_webhook_commit (
      event_id text PRIMARY KEY REFERENCES marketplace_stripe_event_receipt(event_id) ON DELETE RESTRICT,
      payment_id text NOT NULL, capture_id text NOT NULL, cart_id text NOT NULL,
      order_set_id text NOT NULL,
      allocations jsonb NOT NULL CHECK (jsonb_typeof(allocations)='array' AND jsonb_array_length(allocations)>0),
      outbox_ids jsonb NOT NULL CHECK (jsonb_typeof(outbox_ids)='array' AND jsonb_array_length(outbox_ids)>0),
      created_at timestamptz NOT NULL DEFAULT now(),
      FOREIGN KEY (event_id,cart_id) REFERENCES marketplace_webhook_admission(event_id,cart_id) ON DELETE RESTRICT
    );
    ALTER TABLE marketplace_webhook_commit ADD CONSTRAINT marketplace_webhook_commit_payment_fk
      FOREIGN KEY (payment_id) REFERENCES marketplace_capture_tail(payment_id) ON DELETE RESTRICT;
    ALTER TABLE marketplace_webhook_outbox ADD CONSTRAINT marketplace_webhook_outbox_id_event_unique UNIQUE (id,event_id);
    CREATE TABLE marketplace_webhook_consumer_ack (
      outbox_id text NOT NULL,
      subscriber_id text NOT NULL CHECK (subscriber_id='order-set-placed-payment-capture'),
      event_id text NOT NULL REFERENCES marketplace_webhook_commit(event_id) ON DELETE RESTRICT,
      acked_at timestamptz NOT NULL DEFAULT now(),
      PRIMARY KEY (outbox_id,subscriber_id),
      FOREIGN KEY (outbox_id,event_id) REFERENCES marketplace_webhook_outbox(id,event_id) ON DELETE RESTRICT
    );
    CREATE TABLE marketplace_webhook_consumer_attempt (
      outbox_id text PRIMARY KEY REFERENCES marketplace_webhook_outbox(id) ON DELETE RESTRICT,
      available_at timestamptz NOT NULL DEFAULT now(),
      attempts integer NOT NULL DEFAULT 0 CHECK (attempts>=0), last_error text
    );
    CREATE FUNCTION marketplace_webhook_reject_identity_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      RAISE EXCEPTION 'Durable webhook identity rows are append-only' USING ERRCODE = '23514';
    END; $$;
    CREATE TRIGGER marketplace_webhook_admission_append_only BEFORE UPDATE OR DELETE ON marketplace_webhook_admission
      FOR EACH ROW EXECUTE FUNCTION marketplace_webhook_reject_identity_mutation();
    CREATE TRIGGER marketplace_webhook_commit_append_only BEFORE UPDATE OR DELETE ON marketplace_webhook_commit
      FOR EACH ROW EXECUTE FUNCTION marketplace_webhook_reject_identity_mutation();
    CREATE TRIGGER marketplace_webhook_consumer_ack_append_only BEFORE UPDATE OR DELETE ON marketplace_webhook_consumer_ack
      FOR EACH ROW EXECUTE FUNCTION marketplace_webhook_reject_identity_mutation();
    CREATE INDEX marketplace_webhook_admission_pending_idx ON marketplace_webhook_admission(created_at,event_id);
    CREATE INDEX marketplace_webhook_replay_attempt_pending_idx ON marketplace_webhook_replay_attempt(last_attempt_at NULLS FIRST,event_id);
    CREATE INDEX marketplace_webhook_consumer_attempt_pending_idx ON marketplace_webhook_consumer_attempt(available_at,outbox_id);
    REVOKE ALL ON marketplace_webhook_admission,marketplace_webhook_commit,marketplace_webhook_consumer_ack,marketplace_webhook_replay_attempt,marketplace_webhook_consumer_attempt FROM PUBLIC;`)
  }
  override async down(): Promise<void> { throw new Error('Durable webhook identities and ACK evidence cannot be destructively rolled back') }
}
