import { Migration } from '@medusajs/framework/mikro-orm/migrations'

/** Private candidate. Unused until full DB-only completion/finalization is wired.
 * This is a receipt committed WITH business writes, never queue admission.
 */
export class Migration20261006110000 extends Migration {
  override async up(): Promise<void> {
    this.addSql(`CREATE TABLE marketplace_stripe_event_receipt (
      event_id text PRIMARY KEY CHECK (length(event_id)>0),
      fingerprint text NOT NULL CHECK (fingerprint ~ '^[0-9a-f]{64}$'),
      cart_id text NOT NULL,
      payment_collection_id text NOT NULL,
      payment_intent_id text NOT NULL,
      action text NOT NULL,
      applied_at timestamptz NOT NULL DEFAULT now()
    );
    REVOKE ALL ON marketplace_stripe_event_receipt FROM PUBLIC;`)
  }
  override async down(): Promise<void> {
    throw new Error('Stripe event receipts are durable; destructive rollback forbidden')
  }
}
