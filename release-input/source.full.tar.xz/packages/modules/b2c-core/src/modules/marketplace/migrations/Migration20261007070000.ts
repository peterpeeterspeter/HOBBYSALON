import { Migration } from '@medusajs/framework/mikro-orm/migrations'

/** Native migration discovered by the existing marketplace module lifecycle.
 * Raw append-only reconciliation evidence, not a soft-deletable Medusa model.
 * Agreed audit DDL matches scripts/reconciliation/audit_schema.sql; that separate
 * disposable-fixture installer and its isolation guard remain untouched.
 * No runtime/native_repair auto-install, history adoption, or data repair.
 */
export class Migration20261007070000 extends Migration {
  async up(): Promise<void> {
    this.addSql(`CREATE TABLE public.reconciliation_repair_audit (
      id text NOT NULL PRIMARY KEY,
      plan_hash text NOT NULL CHECK (plan_hash ~ '^[a-f0-9]{64}$'),
      case_id text NOT NULL CHECK (length(case_id) BETWEEN 1 AND 255),
      actor text NOT NULL CHECK (length(actor) BETWEEN 1 AND 255),
      evidence jsonb NOT NULL CHECK (jsonb_typeof(evidence)='object'),
      before_snapshot jsonb NOT NULL CHECK (jsonb_typeof(before_snapshot)='object'),
      after_snapshot jsonb NOT NULL CHECK (jsonb_typeof(after_snapshot)='object'),
      created_at timestamptz NOT NULL,
      CHECK (id='recon_' || plan_hash),
      CHECK ((evidence->'provider'->>'account_id' ~ '^acct_[A-Za-z0-9]{1,200}$' AND
        evidence->'provider'->>'provider_effect_id' ~ '^(ch|re)_[A-Za-z0-9]{1,200}$') IS TRUE)
    );
    CREATE UNIQUE INDEX reconciliation_repair_audit_effect_once ON public.reconciliation_repair_audit
      ((evidence->'provider'->>'account_id'), (evidence->'provider'->>'provider_effect_id'));
    CREATE FUNCTION public.reconciliation_repair_audit_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      RAISE EXCEPTION 'reconciliation audit is immutable: update/delete/truncate forbidden';
    END $$;
    CREATE TRIGGER reconciliation_repair_audit_immutable
      BEFORE UPDATE OR DELETE ON public.reconciliation_repair_audit
      FOR EACH ROW EXECUTE FUNCTION public.reconciliation_repair_audit_immutable();
    CREATE TRIGGER reconciliation_repair_audit_no_truncate
      BEFORE TRUNCATE ON public.reconciliation_repair_audit
      FOR EACH STATEMENT EXECUTE FUNCTION public.reconciliation_repair_audit_immutable();
    ALTER TABLE public.reconciliation_repair_audit ENABLE ALWAYS TRIGGER reconciliation_repair_audit_immutable;
    ALTER TABLE public.reconciliation_repair_audit ENABLE ALWAYS TRIGGER reconciliation_repair_audit_no_truncate;`)
  }

  async down(): Promise<void> {
    // Native transactional rollback: lock before checking, so a concurrent
    // INSERT cannot slip between the empty check and DROP. Match the newer
    // capture ACK evidence convention, not the older destructive model rollback.
    // Populated history requires a separately reviewed evidence-preserving plan.
    this.addSql(`LOCK TABLE public.reconciliation_repair_audit IN ACCESS EXCLUSIVE MODE;
    DO $$ BEGIN
      IF EXISTS (SELECT 1 FROM public.reconciliation_repair_audit) THEN
        RAISE EXCEPTION 'refusing rollback with durable reconciliation audit evidence';
      END IF;
    END $$;
    DROP TABLE public.reconciliation_repair_audit;
    DROP FUNCTION public.reconciliation_repair_audit_immutable();`)
  }
}
