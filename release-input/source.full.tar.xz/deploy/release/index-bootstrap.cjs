'use strict';
// Separate metadata-only migrator bootstrap. No service construction, loaders,
// application hooks, consumers or storage providers. Use the deployed compiled config.
function withModuleJoiners(config, cwd, build) {
  const { MedusaModule } = require('@medusajs/modules-sdk');
  const { registerMedusaModule } = require('@medusajs/modules-sdk/dist/loaders');
  const { MODULE_PACKAGE_NAMES } = require('@medusajs/utils');
  // SDK has no deleteJoinerConfig API. Preserve the exact registry instance and
  // restore it in finally; all work here is synchronous and cannot interleave.
  const previous = MedusaModule.joinerConfig_;
  const resolutions = MedusaModule.moduleResolutions_;
  const instances = MedusaModule.instances_, modules = MedusaModule.modules_;
  const customLinks = MedusaModule.customLinks_, customLinksSnapshot = [...customLinks];
  MedusaModule.instances_ = new Map(); MedusaModule.modules_ = new Map();
  MedusaModule.joinerConfig_ = new Map();
  MedusaModule.moduleResolutions_ = new Map();
  try {
    for (const [moduleKey, declaration] of Object.entries(config.modules ?? {})) {
      if (declaration === false || declaration?.disable) continue;
      const moduleDeclaration = typeof declaration === 'object' ? declaration : {};
      const [resolution] = Object.values(registerMedusaModule({ moduleKey,
        moduleDeclaration: { ...moduleDeclaration, resolve: moduleDeclaration.resolve ?? MODULE_PACKAGE_NAMES[moduleKey] }, cwd }));
      let exports = require(resolution.resolutionPath);
      if (exports.discoveryPath) exports = require(exports.discoveryPath);
      const resources = exports.default ?? exports;
      const getJoiner = resources.service?.prototype?.__joinerConfig;
      if (typeof getJoiner !== 'function') {
        if (resolution.definition.isQueryable) throw new Error(`Queryable module lacks native joiner contract: ${moduleKey}`);
        continue;
      }
      // Native joiner methods return metadata without requiring a service instance.
      const joiner = getJoiner.call(resources.service.prototype);
      if (!joiner || typeof joiner.then === 'function') throw new Error(`Unsupported native joiner contract: ${moduleKey}`);
      MedusaModule.setModuleResolution(moduleKey, resolution);
      MedusaModule.setJoinerConfig(moduleKey, joiner);
      // Same partially loaded service shape as SDK migrationOnly; no constructor.
      const hash = `index-metadata:${moduleKey}`;
      MedusaModule.instances_.set(hash, { [moduleKey]: { __joinerConfig: joiner, __definition: resolution.definition } });
      MedusaModule.registerModule(moduleKey, { key: moduleKey, hash, alias: hash, main: true, isLink: false });
    }
    // Register native link metadata exactly as link-modules initialize does,
    // but never bootstrapLink (that would run database/provider loaders).
    const definitions = require('@medusajs/link-modules/dist/definitions');
    const { generateGraphQLSchema } = require('@medusajs/link-modules/dist/utils');
    const { composeLinkName, composeTableName, toPascalCase, simpleHash } = require('@medusajs/utils');
    for (const original of [...Object.values(definitions), ...MedusaModule.getCustomLinks()]) {
      const link = JSON.parse(JSON.stringify(original));
      const [primary, foreign] = link.relationships ?? [];
      if (link.isReadOnlyLink) {
        link.extends = (link.extends ?? []).filter(e => MedusaModule.getJoinerConfig(e.serviceName) && MedusaModule.getJoinerConfig(e.relationship.serviceName));
        if (!link.extends.length) continue;
      } else if (!MedusaModule.getJoinerConfig(primary?.serviceName) || !MedusaModule.getJoinerConfig(foreign?.serviceName)) continue;
      const key = link.isReadOnlyLink ? simpleHash(JSON.stringify(link.extends)) : link.serviceName ?? composeLinkName(primary.serviceName, primary.foreignKey, foreign.serviceName, foreign.foreignKey);
      link.schema = generateGraphQLSchema(link, primary, foreign, { logger: console });
      link.alias = Array.isArray(link.alias) ? link.alias : link.alias ? [link.alias] : [];
      for (const alias of link.alias) {
        alias.args ??= {};
        alias.entity = toPascalCase('Link_' + (link.databaseConfig?.tableName ?? composeTableName(primary.serviceName, primary.foreignKey, foreign.serviceName, foreign.foreignKey)));
      }
      MedusaModule.setJoinerConfig(key, link);
    }
    return build();
  } finally {
    MedusaModule.joinerConfig_ = previous;
    MedusaModule.moduleResolutions_ = resolutions;
    MedusaModule.instances_ = instances; MedusaModule.modules_ = modules;
    customLinks.splice(0, customLinks.length, ...customLinksSnapshot);
    MedusaModule.customLinks_ = customLinks;
  }
}
async function main() {
  const path = require('node:path');
  const env = { ...process.env };
  if (env.RELEASE_INDEX_BOOTSTRAP_APPROVED !== 'yes' || !env.INDEX_MIGRATOR_ROLE || !env.MIGRATOR_DATABASE_URL || !env.DATABASE_SCHEMA) throw new Error('Explicit index migrator approval, role, URL and schema required');
  const configPath = process.argv[2];
  if (!configPath || !path.isAbsolute(configPath) || !configPath.endsWith('.js')) throw new Error('Compiled absolute config path required');
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(env.DATABASE_SCHEMA)) throw new Error('Invalid approved schema');
  // Import under runtime configuration, NOT migrator credentials: metadata import
  // must never make providers inherit elevated roles. Only pg receives this URL.
  const exported = require(configPath);
  const config = exported.default ?? exported;
  const declaration = config.modules?.index;
  if (!declaration || declaration.disable || declaration.resolve !== './src/modules/index-runtime-readonly') throw new Error('Merged wrapper index declaration required');
  if ((declaration.options?.database?.schema ?? config.projectConfig?.databaseSchema ?? 'public') !== env.DATABASE_SCHEMA) throw new Error('Approved schema differs from compiled configuration');
  const wrapper = path.join(path.dirname(configPath), 'src/modules/index-runtime-readonly/catalog.js');
  const { bootstrapNativeIndex } = require(wrapper);
  const { buildSchemaObjectRepresentation, defaultSchema } = require('@medusajs/index/dist/utils');
  const { baseGraphqlSchema } = require('@medusajs/index/dist/utils/base-graphql-schema');
  const { objectRepresentation } = withModuleJoiners(config, path.dirname(configPath), () =>
    buildSchemaObjectRepresentation(baseGraphqlSchema + (declaration.options?.schema ?? defaultSchema)));
  const { Client } = require('pg');
  const client = new Client({ connectionString: env.MIGRATOR_DATABASE_URL, options: `-c search_path=${env.DATABASE_SCHEMA}` });
  await client.connect();
  try {
    const manager = { config: { get: key => key === 'schema' ? env.DATABASE_SCHEMA : undefined }, execute: async (sql, parameters = []) => {
      let i = 0; const translated = sql.replace(/\?/g, () => '$' + (++i));
      const result = await client.query(translated, parameters);
      return Array.isArray(result) ? result.flatMap(r => r.rows ?? []) : result.rows;
    } };
    await bootstrapNativeIndex(manager, objectRepresentation, { approved: true, migratorRole: env.INDEX_MIGRATOR_ROLE });
    console.log('Native index bootstrap postconditions verified');
  } finally { await client.end(); }
}
module.exports = { main, withModuleJoiners };
if (require.main === module) main().catch(error => { console.error(error.message); process.exitCode = 1 });
