#!/usr/bin/env node
'use strict';
const fs = require('node:fs'); const path = require('node:path');
const {workspaces} = require('./audit-dependencies.cjs');
function archive(root, dest) {
  if (fs.existsSync(dest)) throw new Error('Archive destination must not exist');
  const work = workspaces(root);
  for (const [rel,pkg] of work) {
    if (rel.startsWith('apps/') && rel !== 'apps/backend/package.json') throw new Error('Backend install context must omit frontend workspaces');
    const dir = path.join(root,path.dirname(rel));
    if (rel === 'apps/backend/package.json' && !fs.existsSync(path.join(dir,'.medusa/server/medusa-config.js'))) throw new Error('Backend compiled config absent');
    if (rel === 'packages/framework/package.json' && !fs.existsSync(path.join(dir,'dist/index.js'))) throw new Error('Framework dist absent');
    if (rel.startsWith('packages/modules/') && !fs.existsSync(path.join(dir,'.medusa/server/src'))) throw new Error('Native plugin archive absent: '+pkg.name);
  }
  fs.mkdirSync(dest,{recursive:true}); const copied = [];
  function copy(rel) {
    const src = path.join(root,rel); if (!fs.existsSync(src)) return;
    const target = path.join(dest,rel); fs.mkdirSync(path.dirname(target),{recursive:true});
    fs.cpSync(src,target,{recursive:true,dereference:false,verbatimSymlinks:true}); copied.push(rel);
  }
  copy('package.json'); copy('yarn.lock'); copy('node_modules');
  for (const [rel] of work) {
    copy(rel); const dir = path.dirname(rel); copy(dir+'/node_modules');
    copy(dir === 'packages/framework' ? dir+'/dist' : dir+'/.medusa/server');
  }
  // Do not preserve generated type artifacts; startup never generates them.
  fs.rmSync(path.join(dest,'apps/backend/.medusa/server/.medusa'),{recursive:true,force:true});
  return {schema:1,compiled_cwd:'apps/backend/.medusa/server',copied,dependency_policy:'same frozen builder install; development dependencies intentionally retained, no runtime reinstall'};
}
module.exports = {archive};
if (require.main === module) try { console.log(JSON.stringify(archive(path.resolve(process.argv[2] || '/app'),path.resolve(process.argv[3] || '/runtime')),null,2)); }
catch (e) { console.error(e.message); process.exitCode = 2; }