#!/bin/sh
set -eu
# Never perform migrations, seeds, or arbitrary shell commands during normal startup.
command=${1:-start}
if [ "$#" -gt 0 ]; then shift; fi
[ "$#" -eq 0 ] || { printf '%s\n' 'release commands take no arguments' >&2; exit 64; }
case "$command" in
  start)
    cd /app/apps/backend/.medusa/server
    [ -f medusa-config.js ] || { printf '%s\n' 'Compiled config is missing' >&2; exit 78; }
    # Direct compiled CLI: cli.js would register ts-node even in production.
    exec node /app/node_modules/@medusajs/cli/dist/index.js start --types=false --host 0.0.0.0 --port "${PORT:-9000}"
    ;;
  migrate)
    [ "${RELEASE_MIGRATION_APPROVED:-}" = 'yes' ] || { printf '%s\n' 'Migration blocked: explicit RELEASE_MIGRATION_APPROVED=yes required' >&2; exit 78; }
    image_source=$(cat /release/source.sha256)
    [ "${#image_source}" -eq 64 ] || { printf '%s\n' 'Invalid baked source hash' >&2; exit 78; }
    case "$image_source" in *[!0-9a-f]*) printf '%s\n' 'Invalid baked source hash' >&2; exit 78 ;; esac
    [ "${RELEASE_MIGRATION_SOURCE_SHA256:-}" = "$image_source" ] || { printf '%s\n' 'Migration blocked: approved source hash must match baked image receipt' >&2; exit 78; }
    cd /app/apps/backend/.medusa/server
    [ -f medusa-config.js ] || { printf '%s\n' 'Compiled config is missing' >&2; exit 78; }
    # Never execute destructive links implicitly, even for approved migrations.
    case "${RELEASE_MIGRATE_LINKS:-skip}" in
      skip) exec node /app/node_modules/@medusajs/cli/dist/index.js db:migrate --skip-links ;;
      safe) exec node /app/node_modules/@medusajs/cli/dist/index.js db:migrate --execute-safe-links ;;
      *) printf '%s\n' 'Migration blocked: only skip or safe link policy is permitted' >&2; exit 78 ;;
    esac
    ;;
  *) printf '%s\n' 'Allowed commands: start, migrate (explicitly gated)' >&2; exit 64 ;;
esac
