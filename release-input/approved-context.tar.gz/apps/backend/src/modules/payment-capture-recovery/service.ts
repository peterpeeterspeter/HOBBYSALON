import NativePaymentModule from '@medusajs/payment'
import { Collection } from '@medusajs/framework/mikro-orm/core'
import type { CreateCaptureDTO, Context, PaymentDTO } from '@medusajs/framework/types'
import { BigNumber, EmitEvents, InjectManager, MathBN, MedusaContext, MedusaError } from '@medusajs/framework/utils'
import { getAmountFromSmallestUnit, getSmallestUnit } from '@mercurjs/framework'
import { assertCommerceFinancialLock, assertCommercePaymentLock } from '@mercurjs/b2c-core/utils/commerce-cart-lock'

/** Full Stripe capture only. A live private commerce lock capability is mandatory,
 * including native/admin entry points; the database enforces one row per payment.
 * The native capture row commits before dispatch and is never removed on an
 * uncertain provider outcome or failed local write. No outer transaction may
 * encompass dispatch: rolling it back would erase the stable operation identity.
 * Refund/cancel behavior, repositories and native models remain inherited.
 */
export default class PaymentCaptureRecoveryService extends NativePaymentModule.service {
  @InjectManager()
  @EmitEvents()
  async capturePayment(
    input: CreateCaptureDTO,
    @MedusaContext() sharedContext: Context = {}
  ): Promise<PaymentDTO> {
    assertCommerceFinancialLock()
    const reject = (message: string): never => {
      throw new MedusaError(MedusaError.Types.INVALID_DATA, `Full capture recovery: ${message}`)
    }
    if (sharedContext.transactionManager) {
      reject('dispatch cannot run inside an outer transaction')
    }
    const payment = await this.paymentService_.retrieve(input.payment_id, {
      select: ['id', 'data', 'provider_id', 'payment_collection_id', 'amount', 'raw_amount', 'currency_code', 'captured_at', 'canceled_at'],
      relations: ['captures.raw_amount']
    }, sharedContext)
    assertCommerceFinancialLock()
    if (payment.id !== input.payment_id) reject('retrieved payment identity mismatch')
    await assertCommercePaymentLock(payment.id, payment.payment_collection_id)
    assertCommerceFinancialLock()
    if (payment.canceled_at) reject('payment is canceled')
    const currency = payment.currency_code?.toLowerCase()
    if (!currency || !/^[a-z]{3}$/.test(currency)) return reject('invalid payment currency')
    // Native entities expose JSON raw_amount, not a typed BNInput. Preserve its
    // exact value through the same native BigNumber used by capturePayment_.
    const fromRawAmount = (raw: Record<string, unknown>): BigNumber => {
      if (!raw || (typeof raw.value !== 'string' && typeof raw.value !== 'number')) {
        return reject('invalid native raw amount')
      }
      return new BigNumber(raw.value)
    }
    const amount = fromRawAmount(payment.raw_amount)
    if (!MathBN.gt(amount, 0) || !MathBN.eq(payment.amount, amount)) reject('invalid authorized amount')
    if (input.amount !== undefined && !MathBN.eq(input.amount, amount)) reject('only the entire authorized amount is supported')
    const minorAmount = getSmallestUnit(amount, currency)
    if (!Number.isSafeInteger(minorAmount) || minorAmount <= 0 ||
        !MathBN.eq(getAmountFromSmallestUnit(minorAmount, currency), amount)) {
      reject('amount is not exactly representable in provider minor units')
    }
    // Internal retrieve returns entities with MikroORM Collections; serialized
    // DTO adapters expose arrays. Normalize only the validation view: native
    // capturePayment_ must still receive the original entity/Collection (reduce).
    // Do not initialize a missing relation or serialize away native raw amounts.
    const nativeCaptures: unknown = payment.captures
    const captures = Array.isArray(nativeCaptures) ? nativeCaptures
      : nativeCaptures instanceof Collection && nativeCaptures.isInitialized(true)
        ? nativeCaptures.getItems()
        : reject('capture rows are not an initialized native collection or array')
    if (!Array.isArray(captures) || captures.length > 1) reject('ambiguous capture rows')
    let capture: (typeof captures)[number] | undefined = captures[0]
    // Length, rather than truthiness, also rejects null/undefined and sparse rows.
    if (captures.length === 1 && (!capture || typeof capture !== 'object' ||
        typeof capture.id !== 'string' || !capture.id.trim() ||
        (capture.payment_id !== undefined && capture.payment_id !== payment.id) ||
        !MathBN.eq(fromRawAmount(capture.raw_amount), amount) || !MathBN.eq(capture.amount, amount))) {
      reject('existing capture is not a single full capture with a stable identity')
    }
    // Native public capture dispatches even here. Do not call it. Repair only
    // native collection accounting and return a fresh, not pre-update, PaymentDTO.
    if (payment.captured_at) {
      if (!capture) reject('captured payment is missing full capture accounting')
      assertCommerceFinancialLock()
      await this.maybeUpdatePaymentCollection_(payment.payment_collection_id, sharedContext)
      assertCommerceFinancialLock()
      const fresh = await this.retrievePayment(payment.id, { relations: ['captures'] }, sharedContext)
      assertCommerceFinancialLock()
      return fresh
    }
    const providerId = payment.data?.id
    if (typeof providerId !== 'string' || !providerId.trim()) reject('missing provider payment identity')
    const verify = (receipt: Record<string, unknown> | undefined, allowAuthorized: boolean): Record<string, unknown> => {
      if (!receipt || receipt.id !== providerId || receipt.currency !== currency ||
          receipt.amount !== minorAmount) return reject('provider receipt identity, currency or amount mismatch')
      if (receipt.status === 'succeeded') {
        if (receipt.amount_received !== minorAmount || receipt.amount_capturable !== 0) reject('provider did not capture the exact full amount')
      } else if (allowAuthorized && receipt.status === 'requires_capture') {
        if (receipt.amount_received !== 0 || receipt.amount_capturable !== minorAmount) reject('provider authorization is partial or inconsistent')
      } else {
        reject('provider state is canceled, unknown or not safely capturable')
      }
      return receipt
    }
    // getStatus invokes Stripe GET and returns unmodified minor-unit data. The
    // provider retrievePayment API converts amount to major units; do not use it.
    assertCommerceFinancialLock()
    const status = await this.paymentProviderService_.getStatus(payment.provider_id, { data: payment.data ?? undefined })
    assertCommerceFinancialLock()
    let receipt = verify(status.data, true)
    if (!capture) {
      // Retain native transaction-decorated creation, IDs and numeric storage.
      // Do NOT delegate to native public capturePayment: its catch deletes rows.
      // A unique capture(payment_id) conflict escapes before dispatch. A fresh
      // locked retry retrieves and reuses the winner; never invent a second ID.
      assertCommerceFinancialLock()
      const prepared = await this.capturePayment_({ ...input, amount }, payment, sharedContext)
      assertCommerceFinancialLock()
      capture = prepared.capture
      if (!capture?.id) return reject('native capture creation did not return a stable identity')
    }
    if (receipt.status === 'requires_capture') {
      assertCommerceFinancialLock()
      const result = await this.paymentProviderService_.capturePayment(payment.provider_id, {
        data: receipt,
        context: { idempotency_key: capture.id }
      })
      // A lost session after dispatch leaves the stable row for reconciliation.
      // Do not finalize even an exact receipt under a revoked capability.
      assertCommerceFinancialLock()
      receipt = verify(result.data, false)
    }
    // Any exception above/below intentionally retains the committed capture row.
    assertCommerceFinancialLock()
    await this.paymentService_.update({ id: payment.id, data: receipt, captured_at: new Date() }, sharedContext)
    assertCommerceFinancialLock()
    await this.maybeUpdatePaymentCollection_(payment.payment_collection_id, sharedContext)
    assertCommerceFinancialLock()
    const fresh = await this.retrievePayment(payment.id, { relations: ['captures'] }, sharedContext)
    assertCommerceFinancialLock()
    return fresh
  }
}
