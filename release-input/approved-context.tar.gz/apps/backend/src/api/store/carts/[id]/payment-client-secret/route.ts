import type { MedusaRequest, MedusaResponse } from "@medusajs/framework"
import { ContainerRegistrationKeys, Modules } from "@medusajs/framework/utils"
import Stripe from "stripe"
import {
  COMMERCE_PAYMENTS_PAUSED_MESSAGE,
  isCommercePaymentsEnabled,
} from "../../../../middlewares/commerce-payment-policy"

type PaymentClientSecretResponse = MedusaResponse<
  | {
      client_secret?: string
      payment_succeeded?: boolean
      payment_intent_id?: string
    }
  | { message: string }
>

/** Read the active payment status without replacing payment sessions. */
export async function GET(
  req: MedusaRequest<{ id: string }>,
  res: PaymentClientSecretResponse
) {
  return handlePaymentClientSecret(req, res, false)
}

/** Explicit checkout action; only confirmed-canceled sessions may be replaced. */
export async function POST(
  req: MedusaRequest<{ id: string }>,
  res: PaymentClientSecretResponse
) {
  return handlePaymentClientSecret(req, res, true)
}

async function handlePaymentClientSecret(
  req: MedusaRequest<{ id: string }>,
  res: PaymentClientSecretResponse,
  allowRecovery: boolean
) {
  const cartId = req.params.id
  if (!cartId) {
    return res.status(400).json({ message: "Cart ID required" })
  }

  try {
    const query = req.scope.resolve(ContainerRegistrationKeys.QUERY)
    const paymentModuleService = req.scope.resolve(Modules.PAYMENT)
    const stripeKey = process.env.STRIPE_SECRET_API_KEY

    const { data: carts } = await query.graph({
      entity: "cart",
      fields: [
        "id",
        "total",
        "currency_code",
        "region_id",
        "email",
        "payment_collection.id",
        "payment_collection.amount",
        "payment_collection.currency_code",
        "payment_collection.payment_sessions.id",
        "payment_collection.payment_sessions.provider_id",
        "payment_collection.payment_sessions.data",
      ],
      filters: { id: cartId },
    })
    const cart = carts?.[0]

    if (!cart) {
      return res.status(404).json({ message: "Cart not found" })
    }

    const paymentCollection = (cart as {
      payment_collection?: {
        id: string
        amount?: number | { valueOf?: () => number; numeric?: number }
        currency_code?: string
        payment_sessions?: Array<{
          id: string
          provider_id?: string
          data?: Record<string, unknown>
        }>
      }
    })?.payment_collection

    const paymentCollectionId = paymentCollection?.id
    let session = paymentCollection?.payment_sessions?.[0]

    if (!session && paymentCollectionId) {
      const sessions = await paymentModuleService.listPaymentSessions(
        { payment_collection_id: paymentCollectionId },
        { take: 1 }
      )
      session = sessions[0]
    }

    if (!session) {
      return res.status(400).json({
        message: "No payment session found. Initiate payment first.",
      })
    }

    const data = session.data as Record<string, unknown> | undefined
    let clientSecret = (data?.client_secret ?? data?.clientSecret) as string | undefined

    const paymentIntentId =
      (data?.id as string) ?? (typeof session.id === "string" && session.id.startsWith("pi_") ? session.id : null)

    const recreatePaymentSession = async (providerIdOverride?: string) => {
      // Defense in depth: GET can never dispatch delete/create effects.
      if (!allowRecovery) return false
      // Check before deletion as well as creation. A pause preserves recovery.
      if (!isCommercePaymentsEnabled()) {
        return false
      }
      if (!paymentCollectionId) {
        return
      }

      const c = cart as { total?: number; currency_code?: string; email?: string }
      const amountRaw = (paymentCollection as { amount?: number })?.amount ?? c.total ?? 0
      const currency = (paymentCollection as { currency_code?: string })?.currency_code ?? c.currency_code ?? "eur"
      const amount = typeof amountRaw === "object" && amountRaw !== null && "valueOf" in amountRaw
        ? Number((amountRaw as { valueOf: () => number }).valueOf?.())
        : Number(amountRaw)
      const providerId =
        providerIdOverride ??
        (session as { provider_id?: string })?.provider_id ??
        "pp_stripe_stripe-connect"

      if (session?.id) {
        await paymentModuleService.deletePaymentSession(session.id)
      }

      const newSession = await paymentModuleService.createPaymentSession(
        paymentCollectionId,
        {
          provider_id: providerId,
          currency_code: currency,
          amount,
          data: {},
          context: { customer: { email: c.email } },
        } as Parameters<typeof paymentModuleService.createPaymentSession>[1]
      )

      session = newSession as typeof session
      const newData = (newSession as { data?: Record<string, unknown> })?.data
      clientSecret = (newData?.client_secret ?? newData?.clientSecret) as string | undefined
    }

    // Check PaymentIntent status before mutating sessions.
    // Unknown / retrieve failure must NOT delete a possibly-paid session.
    if (paymentIntentId && stripeKey) {
      try {
        const stripe = new Stripe(stripeKey)
        const pi = await stripe.paymentIntents.retrieve(paymentIntentId)
        if (!clientSecret) clientSecret = pi.client_secret ?? undefined

        if (pi.status === "succeeded") {
          return res.json({
            client_secret: clientSecret,
            payment_succeeded: true,
            payment_intent_id: pi.id,
          })
        }

        if (
          pi.status === "processing" ||
          pi.status === "requires_action" ||
          pi.status === "requires_confirmation" ||
          pi.status === "requires_capture"
        ) {
          if (!clientSecret) {
            return res.status(202).json({
              message: "Payment is still processing",
              payment_intent_id: pi.id,
            })
          }
          return res.json({
            client_secret: clientSecret,
            payment_intent_id: pi.id,
          })
        }

        if (pi.status === "canceled") {
          // Never return the canceled intent's secret if replacement fails.
          clientSecret = undefined
          if (!allowRecovery) {
            const enabled = isCommercePaymentsEnabled()
            return res.status(enabled ? 409 : 503).json({
              message: enabled
                ? "Deze betaling is geannuleerd. Start de betaling opnieuw via afrekenen."
                : COMMERCE_PAYMENTS_PAUSED_MESSAGE,
            })
          }
          const recreated = await recreatePaymentSession((session as { provider_id?: string })?.provider_id)
          if (recreated === false) {
            return res.status(503).json({ message: COMMERCE_PAYMENTS_PAUSED_MESSAGE })
          }
        }
      } catch (e) {
        // Status/replacement failure is inconclusive; never retry creation here.
        console.error("[payment-client-secret] Stripe status or session recovery:", e)
        if (!clientSecret) {
          return res.status(202).json({
            message: "Payment status unknown; try again shortly",
            payment_intent_id: paymentIntentId,
          })
        }
        return res.json({
          client_secret: clientSecret,
          payment_intent_id: paymentIntentId,
        })
      }
    }

    // Missing identity is not proof that the provider never created a payment.
    // Only the confirmed-canceled branch above may replace an existing session.
    if (!clientSecret && !paymentIntentId) {
      const enabled = isCommercePaymentsEnabled()
      return res.status(enabled ? 202 : 503).json({
        message: enabled
          ? "De status van je bestaande betaling is nog onbekend. Probeer het later opnieuw."
          : COMMERCE_PAYMENTS_PAUSED_MESSAGE,
      })
    }

    if (!clientSecret) {
      console.warn("[payment-client-secret] FAILED - no client_secret found after all fallbacks")
      return res.status(400).json({
        message: "Payment session has no client_secret",
      })
    }

    return res.json({ client_secret: clientSecret })
  } catch (err) {
    console.error("[payment-client-secret]", err)
    return res.status(500).json({
      message: "Failed to retrieve payment client secret",
    })
  }
}
