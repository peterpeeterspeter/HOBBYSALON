import { AsyncLocalStorage } from 'node:async_hooks'
import { createHash, randomUUID } from 'node:crypto'
import { ContainerRegistrationKeys, MedusaError } from '@medusajs/framework/utils'

type Owner = { container: object; cartId: string; connection: any; knex: any; active: boolean; token: symbol; ownerId: string }
const scope = new AsyncLocalStorage<Owner>()
const owners = new WeakSet<Owner>()
const fail = (message: string): never => { throw new MedusaError(MedusaError.Types.CONFLICT, message) }
const valid = (id: string) => typeof id === 'string' && id.length > 0 && id.length <= 255 && id.trim() === id && !/[\u0000-\u001f\u007f]/.test(id)

/** Same namespaced key at HTTP, webhook, subscriber and operation recovery. */
export function commerceCartLockKey(cartId: string): string {
  if (!valid(cartId)) fail('Invalid commerce cart lock key')
  return createHash('sha256').update(`hobbysalon:commerce-cart:v1:${cartId}`).digest().readBigInt64BE(0).toString()
}

/** Internal capability, never supplied as workflow input or a client token. */
export function assertCommerceCartLock(container: object, cartId: string): void {
  const owner = scope.getStore()
  if (!owner || !owners.has(owner) || !owner.active || owner.container !== container || owner.cartId !== cartId ||
      owner.connection.__knex__disposed || owner.connection._ending || owner.connection._ended) {
    fail('Commerce cart lock is not held; refusing completion effects')
  }
}

/** Financial module entry point: never accept a client-provided capability.
 * The exact container/cart pair comes solely from the active private ALS owner.
 * This must be rechecked after awaits; a lost DB session cannot reserve/dispatch.
 */
export function assertCommerceFinancialLock(): void {
  const owner = scope.getStore()
  if (!owner) return fail('Commerce financial lock is not held')
  assertCommerceCartLock(owner.container, owner.cartId)
}

/** Execute tail ledger statements on the exact session that owns the lock. */
export async function commerceCartLockQuery(container: object, cartId: string, sql: string, bindings: any[] = []): Promise<any> {
  assertCommerceCartLock(container, cartId)
  const owner = scope.getStore()!
  try { return await owner.knex.raw(sql, bindings).connection(owner.connection) }
  catch { owner.active = false; fail('Commerce cart storage failed; reconciliation required') }
}

/** Root PG_CONNECTION Knex only. SESSION advisory lock, no lease/TTL and no ambient transaction.
 * Session-affine PostgreSQL is required (not transaction/statement PgBouncer pooling).
 * Busy acquisition is fail-fast/retryable. Nested same-container/cart work reuses its private capability.
 * A dead process drops the physical session. Uncertain acquisition/unlock discards it, never loans a lock.
 */
export async function withCommerceCartLock<T>(container: any, cartId: string, work: () => Promise<T>): Promise<T> {
  const key = commerceCartLockKey(cartId)
  const inherited = scope.getStore()
  if (inherited) {
    assertCommerceCartLock(container, cartId)
    return work()
  }
  const knex = container.resolve(ContainerRegistrationKeys.PG_CONNECTION)
  const client = knex?.client
  if (!client || knex.isTransaction || client.transacting || typeof knex.raw !== 'function' ||
      typeof client.acquireConnection !== 'function' || typeof client.releaseConnection !== 'function' ||
      typeof client.destroyRawConnection !== 'function') fail('Commerce cart lock requires root PostgreSQL Knex')
  let connection: any
  try { connection = await client.acquireConnection() }
  catch { return fail('Commerce cart lock unavailable; retry required') }
  const raw = (sql: string, bindings: any[] = []) => knex.raw(sql, bindings).connection(connection)
  const owner: Owner = { container, cartId, connection, knex, active: false, token: Symbol(), ownerId: randomUUID() }
  let locked = false, uncertain = true, discard = false, failure: any, value!: T
  const lost = () => { owner.active = false; discard = true }
  connection.on?.('error', lost)
  connection.on?.('end', lost)
  try {
    const response = await raw('SELECT pg_try_advisory_lock(?::bigint) AS locked', [key])
    if (response?.rows?.[0]?.locked === false) { uncertain = false; fail('Commerce cart is busy; retry required') }
    if (response?.rows?.[0]?.locked !== true) fail('Commerce cart lock unavailable; retry required')
    locked = true; uncertain = false
    await raw('SET SESSION synchronous_commit = on')
    owner.active = true; owners.add(owner)
    value = await scope.run(owner, work)
    assertCommerceOwner(owner)
  } catch (error) { failure = error }
  finally {
    owner.active = false; owners.delete(owner)
    discard ||= uncertain
    if (locked) {
      try { if ((await raw('SELECT pg_advisory_unlock(?::bigint) AS unlocked', [key]))?.rows?.[0]?.unlocked !== true) throw new Error() }
      catch { discard = true; failure ??= new MedusaError(MedusaError.Types.CONFLICT, 'Commerce cart unlock failed') }
    }
    connection.removeListener?.('error', lost)
    connection.removeListener?.('end', lost)
    if (!discard) {
      try { await client.releaseConnection(connection) }
      catch { discard = true; failure ??= new MedusaError(MedusaError.Types.CONFLICT, 'Commerce cart connection release failed') }
    }
    if (discard) {
      connection.__knex__disposed = true
      try { await client.destroyRawConnection(connection) } catch { /* disposed validation rejects reuse */ }
      try { await client.releaseConnection(connection) } catch { /* retain original failure */ }
    }
  }
  if (failure) throw failure
  return value
}
function assertCommerceOwner(owner: Owner) {
  if (!owner.active || owner.connection.__knex__disposed || owner.connection._ending || owner.connection._ended) fail('Commerce cart lock ownership lost')
}
